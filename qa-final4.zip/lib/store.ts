import fs from 'fs';
import path from 'path';
import { nanoid } from 'nanoid';

export type OrderStatus = 'Pending' | 'Roasted' | 'Shipped' | 'Cancelled';

export interface Order {
  id: string;
  customerId: string;
  date: string; // ISO
  bags: number;
  status: OrderStatus;
  batch: string;
  revenue: number;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  subscriptionStart: string; // ISO
  address: string;
}

const dataDir = process.env.VERCEL
  ? '/tmp/data'
  : path.join(process.cwd(), 'data');

const ordersPath = path.join(dataDir, 'orders.json');
const customersPath = path.join(dataDir, 'customers.json');

async function ensureDir() {
  await fs.promises.mkdir(dataDir, { recursive: true });
}

async function readJSON<T>(file: string): Promise<T | null> {
  try {
    const txt = await fs.promises.readFile(file, 'utf8');
    return JSON.parse(txt) as T;
  } catch {
    return null;
  }
}

async function writeJSON<T>(file: string, data: T) {
  await fs.promises.writeFile(file, JSON.stringify(data, null, 2), 'utf8');
}

function sampleCustomers(): Customer[] {
  return [
    {
      id: nanoid(),
      name: 'Alice Brew',
      email: 'alice@example.com',
      subscriptionStart: '2023-09-01',
      address: '123 Bean St, Portland, OR',
    },
    {
      id: nanoid(),
      name: 'Bob Roast',
      email: 'bob@example.com',
      subscriptionStart: '2023-10-15',
      address: '456 Roast Rd, Seattle, WA',
    },
    {
      id: nanoid(),
      name: 'Catherine Espresso',
      email: 'catherine@example.com',
      subscriptionStart: '2023-11-05',
      address: '789 Espresso Ave, San Francisco, CA',
    },
  ];
}

function sampleOrders(customers: Customer[]): Order[] {
  const batches = ['Morning Blend', 'Evening Roast', 'Single Origin'];
  const statusOptions: OrderStatus[] = ['Pending', 'Roasted', 'Shipped'];
  const orders: Order[] = [];
  for (let i = 0; i < 8; i++) {
    const cust = customers[i % customers.length];
    const bags = Math.floor(Math.random() * 5) + 1;
    const pricePerBag = 12;
    orders.push({
      id: nanoid(),
      customerId: cust.id,
      date: new Date(Date.now() - i * 86400000).toISOString(),
      bags,
      status: statusOptions[i % statusOptions.length],
      batch: batches[i % batches.length],
      revenue: bags * pricePerBag,
    });
  }
  return orders;
}

export async function loadCustomers(): Promise<Customer[]> {
  await ensureDir();
  let customers = await readJSON<Customer[]>(customersPath);
  if (!customers) {
    customers = sampleCustomers();
    await writeJSON(customersPath, customers);
  }
  return customers;
}

export async function loadOrders(): Promise<Order[]> {
  await ensureDir();
  let orders = await readJSON<Order[]>(ordersPath);
  if (!orders) {
    const customers = await loadCustomers();
    orders = sampleOrders(customers);
    await writeJSON(ordersPath, orders);
  }
  return orders;
}

export async function addCustomer(data: Omit<Customer, 'id'>): Promise<Customer> {
  const customers = await loadCustomers();
  const newCustomer: Customer = { id: nanoid(), ...data };
  customers.push(newCustomer);
  await writeJSON(customersPath, customers);
  return newCustomer;
}

export async function updateCustomer(updated: Customer): Promise<Customer> {
  const customers = await loadCustomers();
  const idx = customers.findIndex(c => c.id === updated.id);
  if (idx >= 0) {
    customers[idx] = updated;
    await writeJSON(customersPath, customers);
  }
  return updated;
}

export async function addOrder(data: Omit<Order, 'id'>): Promise<Order> {
  const orders = await loadOrders();
  const newOrder: Order = { id: nanoid(), ...data };
  orders.push(newOrder);
  await writeJSON(ordersPath, orders);
  return newOrder;
}

export async function updateOrder(updated: Order): Promise<Order> {
  const orders = await loadOrders();
  const idx = orders.findIndex(o => o.id === updated.id);
  if (idx >= 0) {
    orders[idx] = updated;
    await writeJSON(ordersPath, orders);
  }
  return updated;
}