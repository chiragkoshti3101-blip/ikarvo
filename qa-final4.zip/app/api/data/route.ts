import { NextRequest, NextResponse } from 'next/server';
import {
  loadOrders,
  loadCustomers,
  addOrder,
  updateOrder,
  addCustomer,
  updateCustomer,
} from '../../../lib/store';
import type { Order, Customer, OrderStatus } from '../../../lib/store';

const VALID_STATUSES: OrderStatus[] = ['Pending', 'Roasted', 'Shipped', 'Cancelled'];

function getResource(req: NextRequest): string {
  return req.nextUrl.searchParams.get('resource') ?? '';
}

function parseBody(body: unknown): Record<string, unknown> | null {
  if (typeof body !== 'object' || body === null) return null;
  return body as Record<string, unknown>;
}

export async function GET(req: NextRequest) {
  const resource = getResource(req);
  if (resource === 'orders') {
    return NextResponse.json(await loadOrders());
  }
  if (resource === 'customers') {
    return NextResponse.json(await loadCustomers());
  }
  return NextResponse.json(
    { error: 'resource must be "orders" or "customers"' },
    { status: 400 }
  );
}

export async function POST(req: NextRequest) {
  const resource = getResource(req);
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const data = parseBody(body);
  if (!data) {
    return NextResponse.json({ error: 'Body must be an object' }, { status: 400 });
  }

  if (resource === 'orders') {
    if (typeof data.customerId !== 'string' || !data.customerId.trim()) {
      return NextResponse.json({ error: 'customerId is required' }, { status: 400 });
    }
    if (typeof data.date !== 'string' || !data.date.trim()) {
      return NextResponse.json({ error: 'date is required' }, { status: 400 });
    }
    if (typeof data.bags !== 'number' || !Number.isInteger(data.bags) || data.bags <= 0) {
      return NextResponse.json({ error: 'bags must be a positive integer' }, { status: 400 });
    }
    if (typeof data.status !== 'string' || !VALID_STATUSES.includes(data.status as OrderStatus)) {
      return NextResponse.json(
        { error: 'status must be one of Pending, Roasted, Shipped, Cancelled' },
        { status: 400 }
      );
    }
    if (typeof data.batch !== 'string' || !data.batch.trim()) {
      return NextResponse.json({ error: 'batch is required' }, { status: 400 });
    }
    if (typeof data.revenue !== 'number' || data.revenue < 0) {
      return NextResponse.json({ error: 'revenue must be a non-negative number' }, { status: 400 });
    }
    const order = await addOrder({
      customerId: data.customerId,
      date: data.date,
      bags: data.bags,
      status: data.status as OrderStatus,
      batch: data.batch,
      revenue: data.revenue,
    });
    return NextResponse.json(order, { status: 201 });
  }

  if (resource === 'customers') {
    if (typeof data.name !== 'string' || !data.name.trim()) {
      return NextResponse.json({ error: 'name is required' }, { status: 400 });
    }
    if (typeof data.email !== 'string' || !data.email.trim() || !data.email.includes('@')) {
      return NextResponse.json({ error: 'email is required and must be valid' }, { status: 400 });
    }
    if (typeof data.subscriptionStart !== 'string' || !data.subscriptionStart.trim()) {
      return NextResponse.json({ error: 'subscriptionStart is required' }, { status: 400 });
    }
    if (typeof data.address !== 'string' || !data.address.trim()) {
      return NextResponse.json({ error: 'address is required' }, { status: 400 });
    }
    const customer = await addCustomer({
      name: data.name,
      email: data.email,
      subscriptionStart: data.subscriptionStart,
      address: data.address,
    });
    return NextResponse.json(customer, { status: 201 });
  }

  return NextResponse.json(
    { error: 'resource must be "orders" or "customers"' },
    { status: 400 }
  );
}

export async function PUT(req: NextRequest) {
  const resource = getResource(req);
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const data = parseBody(body);
  if (!data) {
    return NextResponse.json({ error: 'Body must be an object' }, { status: 400 });
  }

  if (resource === 'orders') {
    if (typeof data.id !== 'string' || !data.id.trim()) {
      return NextResponse.json({ error: 'id is required' }, { status: 400 });
    }
    const orders = await loadOrders();
    if (!orders.some(o => o.id === data.id)) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }
    if (typeof data.customerId !== 'string' || !data.customerId.trim()) {
      return NextResponse.json({ error: 'customerId is required' }, { status: 400 });
    }
    if (typeof data.date !== 'string' || !data.date.trim()) {
      return NextResponse.json({ error: 'date is required' }, { status: 400 });
    }
    if (typeof data.bags !== 'number' || !Number.isInteger(data.bags) || data.bags <= 0) {
      return NextResponse.json({ error: 'bags must be a positive integer' }, { status: 400 });
    }
    if (typeof data.status !== 'string' || !VALID_STATUSES.includes(data.status as OrderStatus)) {
      return NextResponse.json(
        { error: 'status must be one of Pending, Roasted, Shipped, Cancelled' },
        { status: 400 }
      );
    }
    if (typeof data.batch !== 'string' || !data.batch.trim()) {
      return NextResponse.json({ error: 'batch is required' }, { status: 400 });
    }
    if (typeof data.revenue !== 'number' || data.revenue < 0) {
      return NextResponse.json({ error: 'revenue must be a non-negative number' }, { status: 400 });
    }
    const updated: Order = {
      id: data.id,
      customerId: data.customerId,
      date: data.date,
      bags: data.bags,
      status: data.status as OrderStatus,
      batch: data.batch,
      revenue: data.revenue,
    };
    return NextResponse.json(await updateOrder(updated));
  }

  if (resource === 'customers') {
    if (typeof data.id !== 'string' || !data.id.trim()) {
      return NextResponse.json({ error: 'id is required' }, { status: 400 });
    }
    const customers = await loadCustomers();
    if (!customers.some(c => c.id === data.id)) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 });
    }
    if (typeof data.name !== 'string' || !data.name.trim()) {
      return NextResponse.json({ error: 'name is required' }, { status: 400 });
    }
    if (typeof data.email !== 'string' || !data.email.trim() || !data.email.includes('@')) {
      return NextResponse.json({ error: 'email is required and must be valid' }, { status: 400 });
    }
    if (typeof data.subscriptionStart !== 'string' || !data.subscriptionStart.trim()) {
      return NextResponse.json({ error: 'subscriptionStart is required' }, { status: 400 });
    }
    if (typeof data.address !== 'string' || !data.address.trim()) {
      return NextResponse.json({ error: 'address is required' }, { status: 400 });
    }
    const updated: Customer = {
      id: data.id,
      name: data.name,
      email: data.email,
      subscriptionStart: data.subscriptionStart,
      address: data.address,
    };
    return NextResponse.json(await updateCustomer(updated));
  }

  return NextResponse.json(
    { error: 'resource must be "orders" or "customers"' },
    { status: 400 }
  );
}