'use client';
import { useEffect, useState, ChangeEvent } from 'react';
import { Order, Customer, OrderStatus } from '../lib/store';
import { stringify } from 'csv-stringify/sync';

type SortDirection = 'asc' | 'desc';

export default function Dashboard() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<Set<OrderStatus>>(new Set());
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');

  const [sortKey, setSortKey] = useState<keyof Order>('date');
  const [sortDir, setSortDir] = useState<SortDirection>('desc');

  // Load data
  useEffect(() => {
    async function fetchData() {
      try {
        const res = await fetch('/api/data');
        if (!res.ok) throw new Error('Failed to load data');
        const data = await res.json();
        setOrders(data.orders);
        setCustomers(data.customers);
        setLoading(false);
      } catch (e) {
        setError((e as Error).message);
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  // Helper to get customer name
  const getCustomerName = (id: string) => {
    const c = customers.find(c => c.id === id);
    return c ? c.name : 'Unknown';
  };

  // Filtering
  const filtered = orders.filter(o => {
    const custName = getCustomerName(o.customerId).toLowerCase();
    const custEmail = (customers.find(c => c.id === o.customerId)?.email ?? '').toLowerCase();
    const term = search.trim().toLowerCase();
    const matchesSearch = !term || custName.includes(term) || custEmail.includes(term);
    const matchesStatus = statusFilter.size === 0 || statusFilter.has(o.status);
    const orderDate = new Date(o.date);
    const matchesFrom = !dateFrom || orderDate >= new Date(dateFrom);
    const matchesTo = !dateTo || orderDate <= new Date(dateTo);
    return matchesSearch && matchesStatus && matchesFrom && matchesTo;
  });

  // Sorting
  const sorted = [...filtered].sort((a, b) => {
    const aVal = a[sortKey];
    const bVal = b[sortKey];
    if (aVal < bVal) return sortDir === 'asc' ? -1 : 1;
    if (aVal > bVal) return sortDir === 'asc' ? 1 : -1;
    return 0;
  });

  // KPI calculations (this week)
  const startOfWeek = new Date();
  startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
  const weekOrders = orders.filter(o => new Date(o.date) >= startOfWeek);
  const totalRevenue = weekOrders.reduce((sum, o) => sum + o.revenue, 0);
  const openOrders = weekOrders.filter(o => o.status !== 'Shipped' && o.status !== 'Cancelled').length;
  const totalBags = weekOrders.reduce((sum, o) => sum + o.bags, 0);
  const batchSet = new Set(weekOrders.map(o => o.batch));
  const distinctBatches = batchSet.size;

  // Handlers
  const toggleStatus = (status: OrderStatus) => {
    const newSet = new Set(statusFilter);
    if (newSet.has(status)) newSet.delete(status);
    else newSet.add(status);
    setStatusFilter(newSet);
  };

  const handleSort = (key: keyof Order) => {
    if (sortKey === key) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  const updateOrderStatus = async (order: Order, newStatus: OrderStatus) => {
    const updated = { ...order, status: newStatus };
    try {
      const res = await fetch('/api/data', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
      if (!res.ok) throw new Error('Update failed');
      setOrders(prev => prev.map(o => (o.id === updated.id ? updated : o)));
    } catch (e) {
      alert((e as Error).message);
    }
  };

  const exportCSV = () => {
    const rows = sorted.map(o => ({
      OrderID: o.id,
      Date: o.date.split('T')[0],
      Customer: getCustomerName(o.customerId),
      Email: customers.find(c => c.id === o.customerId)?.email ?? '',
      Batch: o.batch,
      Bags: o.bags,
      Revenue: o.revenue.toFixed(2),
      Status: o.status,
    }));
    const csv = stringify(rows, { header: true });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'orders_export.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <div className="dashboard">Loading…</div>;
  if (error) return <div className="dashboard error">Error: {error}</div>;

  return (
    <div className="dashboard">
      <h1 className="title">Ember &amp; Oak – Weekly Subscription Orders</h1>

      <section className="kpi-row">
        <div className="kpi">
          <div className="kpi-label">Revenue (this week)</div>
          <div className="kpi-value">${totalRevenue.toFixed(2)}</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Open Orders</div>
          <div className="kpi-value">{openOrders}</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Bags to Ship</div>
          <div className="kpi-value">{totalBags}</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Batches</div>
          <div className="kpi-value">{distinctBatches}</div>
        </div>
      </section>

      <section className="filters">
        <input
          type="text"
          placeholder="Search customers…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="search-input"
        />
        <div className="status-chips">
          {(['Pending', 'Roasted', 'Shipped', 'Cancelled'] as OrderStatus[]).map(s => (
            <button
              key={s}
              className={`chip ${statusFilter.has(s) ? 'active' : ''}`}
              onClick={() => toggleStatus(s)}
            >
              {s}
            </button>
          ))}
        </div>
        <div className="date-filters">
          <label>
            From
            <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
          </label>
          <label>
            To
            <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} />
          </label>
        </div>
        <button className="export-btn" onClick={exportCSV}>
          Export CSV
        </button>
      </section>

      <section className="table-section">
        {sorted.length === 0 ? (
          <div className="empty-state">No orders match the current filters.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th onClick={() => handleSort('date')}>Date {sortKey === 'date' && (sortDir === 'asc' ? '▲' : '▼')}</th>
                <th onClick={() => handleSort('customerId')}>Customer {sortKey === 'customerId' && (sortDir === 'asc' ? '▲' : '▼')}</th>
                <th onClick={() => handleSort('batch')}>Batch {sortKey === 'batch' && (sortDir === 'asc' ? '▲' : '▼')}</th>
                <th onClick={() => handleSort('bags')}>Bags {sortKey === 'bags' && (sortDir === 'asc' ? '▲' : '▼')}</th>
                <th onClick={() => handleSort('revenue')}>Revenue {sortKey === 'revenue' && (sortDir === 'asc' ? '▲' : '▼')}</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map(o => (
                <tr key={o.id}>
                  <td>{new Date(o.date).toLocaleDateString()}</td>
                  <td>{getCustomerName(o.customerId)}</td>
                  <td>{o.batch}</td>
                  <td>{o.bags}</td>
                  <td>${o.revenue.toFixed(2)}</td>
                  <td>
                    <select
                      value={o.status}
                      onChange={e => updateOrderStatus(o, e.target.value as OrderStatus)}
                      className="status-select"
                    >
                      {(['Pending', 'Roasted', 'Shipped', 'Cancelled'] as OrderStatus[]).map(s => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}