import './globals.css';
import Link from 'next/link';
import { ReactNode } from 'react';

export const metadata = {
  title: 'Ember & Oak – Order Desk',
  description: 'Manage weekly subscription orders for Ember & Oak coffee roastery',
};

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="app-shell">
        <aside className="sidebar">
          <nav className="nav">
            <Link href="/" className="nav-link">Dashboard</Link>
            <Link href="/orders" className="nav-link">Orders</Link>
            <Link href="/customers" className="nav-link">Customers</Link>
            <Link href="/settings" className="nav-link">Settings</Link>
          </nav>
        </aside>
        <main className="main-content">{children}</main>
      </body>
    </html>
  );
}