import { promises as fs } from 'fs';
import path from 'path';
import { randomUUID } from 'crypto';

export type OrderStatus = 'Pending' | 'Roasting' | 'Shipped' | 'Cancelled';

export interface Order {
  id: string;
  customerId: string;
  orderDate: string;
  deliveryDate: string;
  bags: number;
  status: OrderStatus;
  revenue: number;
  roastBatch: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  subscriptionStart: string;
  subscriptionStatus: 'Active' | 'Paused' | 'Cancelled';
}

const dataDir = process.env.VERCEL ? '/tmp/data' : path.join(process.cwd(), 'data');
const ordersFile = path.join(dataDir, 'orders.json');
const customersFile = path.join(dataDir, 'customers.json');

async function ensureDir() {
  await fs.mkdir(dataDir, { recursive: true });
}

async function readJson<T>(file: string): Promise<T[]> {
  try {
    const data = await fs.readFile(file, 'utf8');
    return JSON.parse(data) as T[];
  } catch {
    return [];
  }
}

async function writeJson<T>(file: string, data: T[]): Promise<void> {
  await fs.writeFile(file, JSON.stringify(data, null, 2), 'utf8');
}

async function seedIfEmpty() {
  await ensureDir();
  const customers = await readJson<Customer>(customersFile);
  if (customers.length === 0) {
    const sampleCustomers: Customer[] = [
      {
        id: randomUUID(),
        name: 'Alice Brew',
        email: 'alice@example.com',
        phone: '555‑1234',
        address: '123 Bean St, Roastville',
        subscriptionStart: new Date().toISOString(),
        subscriptionStatus: 'Active',
      },
      {
        id: randomUUID(),
        name: 'Bob Roast',
        email: 'bob@example.com',
        phone: '555‑5678',
        address: '456 Aroma Ave, Brewtown',
        subscriptionStart: new Date().toISOString(),
        subscriptionStatus: 'Active',
      },
      {
        id: randomUUID(),
        name: 'Carol Espresso',
        email: 'carol@example.com',
        phone: '555‑9012',
        address: '789 Caffeine Rd, Bean City',
        subscriptionStart: new Date().toISOString(),
        subscriptionStatus: 'Paused',
      },
    ];
    await writeJson(customersFile, sampleCustomers);
    const sampleOrders: Order[] = [
      {
        id: randomUUID(),
        customerId: sampleCustomers[0].id,
        orderDate: new Date().toISOString(),
        deliveryDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
        bags: 2,
        status: 'Pending',
        revenue: 24.0,
        roastBatch: 'Batch A',
      },
      {
        id: randomUUID(),
        customerId: sampleCustomers[1].id,
        orderDate: new Date().toISOString(),
        deliveryDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
        bags: 1,
        status: 'Roasting',
        revenue: 12.0,
        roastBatch: 'Batch B',
      },
      {
        id: randomUUID(),
        customerId: sampleCustomers[2].id,
        orderDate: new Date().toISOString(),
        deliveryDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
        bags: 3,
        status: 'Shipped',
        revenue: 36.0,
        roastBatch: 'Batch A',
      },
      {
        id: randomUUID(),
        customerId: sampleCustomers[0].id,
        orderDate: new Date().toISOString(),
        deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        bags: 2,
        status: 'Cancelled',
        revenue: 0,
        roastBatch: '',
      },
    ];
    await writeJson(ordersFile, sampleOrders);
  }
}

export async function getCustomers(): Promise<Customer[]> {
  await seedIfEmpty();
  return await readJson<Customer>(customersFile);
}

export async function getOrders(): Promise<Order[]> {
  await seedIfEmpty();
  return await readJson<Order>(ordersFile);
}

export async function addCustomer(data: Omit<Customer, 'id'>): Promise<Customer> {
  await seedIfEmpty();
  const customers = await readJson<Customer>(customersFile);
  const newCustomer: Customer = { id: randomUUID(), ...data };
  customers.push(newCustomer);
  await writeJson(customersFile, customers);
  return newCustomer;
}

export async function addOrder(data: Omit<Order, 'id'>): Promise<Order> {
  await seedIfEmpty();
  const orders = await readJson<Order>(ordersFile);
  const newOrder: Order = { id: randomUUID(), ...data };
  orders.push(newOrder);
  await writeJson(ordersFile, orders);
  return newOrder;
}

export async function updateOrderStatus(orderId: string, status: OrderStatus): Promise<Order | null> {
  await seedIfEmpty();
  const orders = await readJson<Order>(ordersFile);
  const idx = orders.findIndex(o => o.id === orderId);
  if (idx === -1) return null;
  orders[idx].status = status;
  await writeJson(ordersFile, orders);
  return orders[idx];
}