'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

type OrderStatus = 'pending' | 'roasting' | 'packed' | 'shipped';

type Order = {
  id: string;
  customerId: string;
  customerName: string;
  roast: string;
  weight: number;
  quantity: number;
  total: number;
  status: OrderStatus;
  createdAt: string;
  shipBy: string;
  batch: string;
};

type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  state: string;
  subscription: string;
  since: string;
  lastOrder: string;
  lifetimeValue: number;
};

type SortKey = 'createdAt' | 'total' | 'customerName' | 'status' | 'shipBy' | 'name' | 'city' | 'since' | 'lifetimeValue' | 'lastOrder';

type SortDir = 'asc' | 'desc';

const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending',
  roasting: 'Roasting',
  packed: 'Packed',
  shipped: 'Shipped',
};

const ROASTS = ['House Blend', 'Single Origin Ethiopia', 'Colombia Huila', 'Sumatra Mandheling', 'Decaf Swiss Water', 'Costa Rica Tarrazu'];

const STATUS_OPTIONS: OrderStatus[] = ['pending', 'roasting', 'packed', 'shipped'];

const todayISO = () => new Date().toISOString().slice(0, 10);

const daysAgoISO = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
};

const daysAheadISO = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
};

const formatCurrency = (value: number) => `$${value.toFixed(2)}`;

const formatDate = (iso: string) => {
  const d = new Date(iso);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

function parseDateInput(value: string): string {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  return d.toISOString().slice(0, 10);
}

function matchesDateRange(iso: string, from: string, to: string): boolean {
  const date = iso.slice(0, 10);
  if (from && date < from) return false;
  if (to && date > to) return false;
  return true;
}

function matchesSearch(text: string, query: string): boolean {
  if (!query) return true;
  return text.toLowerCase().includes(query.toLowerCase());
}

function formatCSV(rows: Record<string, unknown>[], headers: { key: string; label: string }[]): string {
  const escape = (value: unknown) => {
    const s = String(value ?? '');
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  const lines = [headers.map((h) => escape(h.label)).join(',')];
  for (const row of rows) {
    lines.push(headers.map((h) => escape(row[h.key])).join(','));
  }
  return lines.join('\n');
}

function downloadCSV(filename: string, content: string) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export default function OrderDeskPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [activeTab, setActiveTab] = useState<'orders' | 'customers'>('orders');
  const [orderSearch, setOrderSearch] = useState('');
  const [customerSearch, setCustomerSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [roastFilter, setRoastFilter] = useState<string>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [orderSortKey, setOrderSortKey] = useState<SortKey>('createdAt');
  const [orderSortDir, setOrderSortDir] = useState<SortDir>('desc');
  const [customerSortKey, setCustomerSortKey] = useState<SortKey>('name');
  const [customerSortDir, setCustomerSortDir] = useState<SortDir>('asc');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exportNotice, setExportNotice] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [updateError, setUpdateError] = useState<string | null>(null);
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [ordersRes, customersRes] = await Promise.all([
        fetch('/api/data?resource=orders'),
        fetch('/api/data?resource=customers'),
      ]);
      if (!ordersRes.ok) throw new Error('Failed to load orders');
      if (!customersRes.ok) throw new Error('Failed to load customers');
      const ordersData = await ordersRes.json();
      const customersData = await customersRes.json();
      setOrders(ordersData.orders ?? []);
      setCustomers(customersData.customers ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong loading the order desk.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const showNotice = useCallback((message: string) => {
    setExportNotice(message);
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    noticeTimer.current = setTimeout(() => setExportNotice(null), 2600);
  }, []);

  const updateOrderStatus = useCallback(
    async (orderId: string, status: OrderStatus) => {
      setUpdatingId(orderId);
      setUpdateError(null);
      try {
        const res = await fetch('/api/data?resource=orders', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: orderId, status }),
        });
        if (!res.ok) {
          const body = await res.json().catch(() => null);
          throw new Error(body?.error ?? 'Failed to update order status');
        }
        const data = await res.json();
        setOrders((prev) => prev.map((o) => (o.id === orderId ? data.order : o)));
        showNotice(`Order ${orderId.slice(0, 8).toUpperCase()} marked ${STATUS_LABELS[status]}.`);
      } catch (err) {
        setUpdateError(err instanceof Error ? err.message : 'Failed to update order status.');
      } finally {
        setUpdatingId(null);
      }
    },
    [showNotice],
  );

  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      if (statusFilter !== 'all' && order.status !== statusFilter) return false;
      if (roastFilter !== 'all' && order.roast !== roastFilter) return false;
      if (!matchesDateRange(order.createdAt, dateFrom, dateTo)) return false;
      const haystack = `${order.customerName} ${order.roast} ${order.batch} ${order.id}`;
      return matchesSearch(haystack, orderSearch);
    });
  }, [orders, statusFilter, roastFilter, dateFrom, dateTo, orderSearch]);

  const sortedOrders = useMemo(() => {
    const sorted = [...filteredOrders];
    sorted.sort((a, b) => {
      const aVal = a[orderSortKey as keyof Order];
      const bVal = b[orderSortKey as keyof Order];
      let cmp = 0;
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        cmp = aVal - bVal;
      } else {
        cmp = String(aVal).localeCompare(String(bVal));
      }
      return orderSortDir === 'asc' ? cmp : -cmp;
    });
    return sorted;
  }, [filteredOrders, orderSortKey, orderSortDir]);

  const filteredCustomers = useMemo(() => {
    return customers.filter((customer) => {
      const haystack = `${customer.name} ${customer.email} ${customer.city} ${customer.state} ${customer.subscription}`;
      return matchesSearch(haystack, customerSearch);
    });
  }, [customers, customerSearch]);

  const sortedCustomers = useMemo(() => {
    const sorted = [...filteredCustomers];
    sorted.sort((a, b) => {
      const aVal = a[customerSortKey as keyof Customer];
      const bVal = b[customerSortKey as keyof Customer];
      let cmp = 0;
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        cmp = aVal - bVal;
      } else {
        cmp = String(aVal).localeCompare(String(bVal));
      }
      return customerSortDir === 'asc' ? cmp : -cmp;
    });
    return sorted;
  }, [filteredCustomers, customerSortKey, customerSortDir]);

  const kpis = useMemo(() => {
    const weekStart = daysAgoISO(6);
    const weekOrders = orders.filter((o) => o.createdAt.slice(0, 10) >= weekStart);
    const revenue = weekOrders.reduce((sum, o) => sum + o.total, 0);
    const openOrders = orders.filter((o) => o.status !== 'shipped').length;
    const bags = weekOrders.reduce((sum, o) => sum + o.quantity, 0);
    const batches = new Set(weekOrders.map((o) => o.batch)).size;
    return { revenue, openOrders, bags, batches };
  }, [orders]);

  const toggleOrderSort = useCallback((key: SortKey) => {
    setOrderSortKey((prevKey) => {
      if (prevKey === key) {
        setOrderSortDir((prevDir) => (prevDir === 'asc' ? 'desc' : 'asc'));
        return prevKey;
      }
      setOrderSortDir('desc');
      return key;
    });
  }, []);

  const toggleCustomerSort = useCallback((key: SortKey) => {
    setCustomerSortKey((prevKey) => {
      if (prevKey === key) {
        setCustomerSortDir((prevDir) => (prevDir === 'asc' ? 'desc' : 'asc'));
        return prevKey;
      }
      setCustomerSortDir('asc');
      return key;
    });
  }, []);

  const exportOrdersCSV = useCallback(() => {
    if (sortedOrders.length === 0) {
      showNotice('No orders to export for the current view.');
      return;
    }
    const headers = [
      { key: 'id', label: 'Order ID' },
      { key: 'customerName', label: 'Customer' },
      { key: 'roast', label: 'Roast' },
      { key: 'weight', label: 'Weight (g)' },
      { key: 'quantity', label: 'Bags' },
      { key: 'total', label: 'Total' },
      { key: 'status', label: 'Status' },
      { key: 'createdAt', label: 'Order Date' },
      { key: 'shipBy', label: 'Ship By' },
      { key: 'batch', label: 'Batch' },
    ];
    const rows = sortedOrders.map((o) => ({
      id: o.id,
      customerName: o.customerName,
      roast: o.roast,
      weight: o.weight,
      quantity: o.quantity,
      total: o.total.toFixed(2),
      status: STATUS_LABELS[o.status],
      createdAt: o.createdAt.slice(0, 10),
      shipBy: o.shipBy.slice(0, 10),
      batch: o.batch,
    }));
    downloadCSV(`ember-oak-orders-${todayISO()}.csv`, formatCSV(rows, headers));
    showNotice('Orders CSV downloaded.');
  }, [sortedOrders, showNotice]);

  const exportCustomersCSV = useCallback(() => {
    if (sortedCustomers.length === 0) {
      showNotice('No customers to export for the current view.');
      return;
    }
    const headers = [
      { key: 'id', label: 'Customer ID' },
      { key: 'name', label: 'Name' },
      { key: 'email', label: 'Email' },
      { key: 'phone', label: 'Phone' },
      { key: 'city', label: 'City' },
      { key: 'state', label: 'State' },
      { key: 'subscription', label: 'Subscription' },
      { key: 'since', label: 'Customer Since' },
      { key: 'lastOrder', label: 'Last Order' },
      { key: 'lifetimeValue', label: 'Lifetime Value' },
    ];
    const rows = sortedCustomers.map((c) => ({
      id: c.id,
      name: c.name,
      email: c.email,
      phone: c.phone,
      city: c.city,
      state: c.state,
      subscription: c.subscription,
      since: c.since.slice(0, 10),
      lastOrder: c.lastOrder.slice(0, 10),
      lifetimeValue: c.lifetimeValue.toFixed(2),
    }));
    downloadCSV(`ember-oak-customers-${todayISO()}.csv`, formatCSV(rows, headers));
    showNotice('Customers CSV downloaded.');
  }, [sortedCustomers, showNotice]);

  const clearOrderFilters = useCallback(() => {
    setOrderSearch('');
    setStatusFilter('all');
    setRoastFilter('all');
    setDateFrom('');
    setDateTo('');
  }, []);

  const clearCustomerFilters = useCallback(() => {
    setCustomerSearch('');
  }, []);

  const orderFiltersActive = orderSearch !== '' || statusFilter !== 'all' || roastFilter !== 'all' || dateFrom !== '' || dateTo !== '';
  const customerFiltersActive = customerSearch !== '';

  const orderSortArrow = (key: SortKey) => {
    if (orderSortKey !== key) return '';
    return orderSortDir === 'asc' ? ' ↑' : ' ↓';
  };

  const customerSortArrow = (key: SortKey) => {
    if (customerSortKey !== key) return '';
    return customerSortDir === 'asc' ? ' ↑' : ' ↓';
  };

  return (
    <div className="desk-shell">
      <header className="desk-header">
        <div className="desk-heading">
          <h1>Order Desk</h1>
          <p className="desk-subtitle">This week&apos;s subscription orders, roast batches, and customer accounts for Ember &amp; Oak.</p>
        </div>
        <div className="desk-header-actions">
          {activeTab === 'orders' ? (
            <button type="button" className="btn btn-secondary" onClick={exportOrdersCSV}>
              Export orders CSV
            </button>
          ) : (
            <button type="button" className="btn btn-secondary" onClick={exportCustomersCSV}>
              Export customers CSV
            </button>
          )}
        </div>
      </header>

      {exportNotice && <div className="notice-banner" role="status">{exportNotice}</div>}
      {updateError && <div className="notice-banner notice-error" role="alert">{updateError}</div>}
      {error && (
        <div className="error-state">
          <p>{error}</p>
          <button type="button" className="btn btn-primary" onClick={fetchData}>Try again</button>
        </div>
      )}

      {loading ? (
        <div className="loading-state" role="status">
          <span className="spinner" aria-hidden="true" />
          <p>Loading the order desk…</p>
        </div>
      ) : (
        <>
          <section className="kpi-row" aria-label="This week at a glance">
            <div className="kpi-card">
              <span className="kpi-label">Week revenue</span>
              <span className="kpi-value">{formatCurrency(kpis.revenue)}</span>
              <span className="kpi-note">Orders placed in last 7 days</span>
            </div>
            <div className="kpi-card">
              <span className="kpi-label">Open orders</span>
              <span className="kpi-value">{kpis.openOrders}</span>
              <span className="kpi-note">Not yet shipped</span>
            </div>
            <div className="kpi-card">
              <span className="kpi-label">Bags this week</span>
              <span className="kpi-value">{kpis.bags}</span>
              <span className="kpi-note">250g bags in week orders</span>
            </div>
            <div className="kpi-card">
              <span className="kpi-label">Roast batches</span>
              <span className="kpi-value">{kpis.batches}</span>
              <span className="kpi-note">Unique batches this week</span>
            </div>
          </section>

          <div className="tab-bar" role="tablist" aria-label="Order desk sections">
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'orders'}
              className={`tab-button ${activeTab === 'orders' ? 'tab-active' : ''}`}
              onClick={() => setActiveTab('orders')}
            >
              Orders
              <span className="tab-count">{orders.length}</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'customers'}
              className={`tab-button ${activeTab === 'customers' ? 'tab-active' : ''}`}
              onClick={() => setActiveTab('customers')}
            >
              Customers
              <span className="tab-count">{customers.length}</span>
            </button>
          </div>

          {activeTab === 'orders' ? (
            <section className="data-panel" aria-label="Orders">
              <div className="filter-bar">
                <div className="search-field">
                  <label className="sr-only" htmlFor="order-search">Search orders</label>
                  <input
                    id="order-search"
                    type="search"
                    placeholder="Search by customer, roast, or batch…"
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                  />
                </div>
                <div className="filter-chips" role="group" aria-label="Filter by status">
                  <button
                    type="button"
                    className={`chip ${statusFilter === 'all' ? 'chip-active' : ''}`}
                    onClick={() => setStatusFilter('all')}
                  >
                    All
                  </button>
                  {STATUS_OPTIONS.map((status) => (
                    <button
                      key={status}
                      type="button"
                      className={`chip ${statusFilter === status ? 'chip-active' : ''}`}
                      onClick={() => setStatusFilter(status)}
                    >
                      {STATUS_LABELS[status]}
                    </button>
                  ))}
                </div>
                <div className="filter-select">
                  <label className="sr-only" htmlFor="roast-filter">Filter by roast</label>
                  <select id="roast-filter" value={roastFilter} onChange={(e) => setRoastFilter(e.target.value)}>
                    <option value="all">All roasts</option>
                    {ROASTS.map((roast) => (
                      <option key={roast} value={roast}>{roast}</option>
                    ))}
                  </select>
                </div>
                <div className="date-range">
                  <div className="date-field">
                    <label htmlFor="date-from">From</label>
                    <input
                      id="date-from"
                      type="date"
                      value={dateFrom}
                      max={dateTo || undefined}
                      onChange={(e) => setDateFrom(parseDateInput(e.target.value))}
                    />
                  </div>
                  <div className="date-field">
                    <label htmlFor="date-to">To</label>
                    <input
                      id="date-to"
                      type="date"
                      value={dateTo}
                      min={dateFrom || undefined}
                      onChange={(e) => setDateTo(parseDateInput(e.target.value))}
                    />
                  </div>
                </div>
                {orderFiltersActive && (
                  <button type="button" className="btn btn-link" onClick={clearOrderFilters}>
                    Clear filters
                  </button>
                )}
              </div>

              {sortedOrders.length === 0 ? (
                <div className="empty-state">
                  <h2>No orders match this view</h2>
                  <p>Try adjusting your search, status chips, roast filter, or date range.</p>
                  <button type="button" className="btn btn-primary" onClick={clearOrderFilters}>
                    Clear all filters
                  </button>
                </div>
              ) : (
                <div className="table-wrap">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleOrderSort('customerName')}>
                            Customer{orderSortArrow('customerName')}
                          </button>
                        </th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleOrderSort('roast')}>
                            Roast{orderSortArrow('roast')}
                          </button>
                        </th>
                        <th className="num-col">
                          <button type="button" className="th-button" onClick={() => toggleOrderSort('quantity')}>
                            Bags{orderSortArrow('quantity')}
                          </button>
                        </th>
                        <th className="num-col">
                          <button type="button" className="th-button" onClick={() => toggleOrderSort('total')}>
                            Total{orderSortArrow('total')}
                          </button>
                        </th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleOrderSort('status')}>
                            Status{orderSortArrow('status')}
                          </button>
                        </th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleOrderSort('createdAt')}>
                            Order date{orderSortArrow('createdAt')}
                          </button>
                        </th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleOrderSort('shipBy')}>
                            Ship by{orderSortArrow('shipBy')}
                          </button>
                        </th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleOrderSort('batch')}>
                            Batch{orderSortArrow('batch')}
                          </button>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedOrders.map((order) => (
                        <tr key={order.id}>
                          <td className="cell-primary">{order.customerName}</td>
                          <td>{order.roast}</td>
                          <td className="num-col">{order.quantity}</td>
                          <td className="num-col">{formatCurrency(order.total)}</td>
                          <td>
                            <div className="status-cell">
                              <span className={`status-dot status-${order.status}`} aria-hidden="true" />
                              <select
                                className={`status-select status-${order.status}`}
                                value={order.status}
                                disabled={updatingId === order.id}
                                aria-label={`Status for order ${order.id}`}
                                onChange={(e) => updateOrderStatus(order.id, e.target.value as OrderStatus)}
                              >
                                {STATUS_OPTIONS.map((status) => (
                                  <option key={status} value={status}>{STATUS_LABELS[status]}</option>
                                ))}
                              </select>
                              {updatingId === order.id && <span className="inline-spinner" aria-hidden="true" />}
                            </div>
                          </td>
                          <td>{formatDate(order.createdAt)}</td>
                          <td>{formatDate(order.shipBy)}</td>
                          <td><span className="batch-tag">{order.batch}</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          ) : (
            <section className="data-panel" aria-label="Customers">
              <div className="filter-bar">
                <div className="search-field">
                  <label className="sr-only" htmlFor="customer-search">Search customers</label>
                  <input
                    id="customer-search"
                    type="search"
                    placeholder="Search by name, email, city, or subscription…"
                    value={customerSearch}
                    onChange={(e) => setCustomerSearch(e.target.value)}
                  />
                </div>
                {customerFiltersActive && (
                  <button type="button" className="btn btn-link" onClick={clearCustomerFilters}>
                    Clear search
                  </button>
                )}
              </div>

              {sortedCustomers.length === 0 ? (
                <div className="empty-state">
                  <h2>No customers match this search</h2>
                  <p>Try a different name, email, city, or subscription term.</p>
                  <button type="button" className="btn btn-primary" onClick={clearCustomerFilters}>
                    Clear search
                  </button>
                </div>
              ) : (
                <div className="table-wrap">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleCustomerSort('name')}>
                            Name{customerSortArrow('name')}
                          </button>
                        </th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleCustomerSort('city')}>
                            City{customerSortArrow('city')}
                          </button>
                        </th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleCustomerSort('subscription')}>
                            Subscription{customerSortArrow('subscription')}
                          </button>
                        </th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleCustomerSort('since')}>
                            Customer since{customerSortArrow('since')}
                          </button>
                        </th>
                        <th>
                          <button type="button" className="th-button" onClick={() => toggleCustomerSort('lastOrder')}>
                            Last order{customerSortArrow('lastOrder')}
                          </button>
                        </th>
                        <th className="num-col">
                          <button type="button" className="th-button" onClick={() => toggleCustomerSort('lifetimeValue')}>
                            Lifetime value{customerSortArrow('lifetimeValue')}
                          </button>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedCustomers.map((customer) => (
                        <tr key={customer.id}>
                          <td className="cell-primary">{customer.name}</td>
                          <td><a className="cell-link" href={`mailto:${customer.email}`}>{customer.email}</a></td>
                          <td>{customer.phone}</td>
                          <td>{customer.city}, {customer.state}</td>
                          <td><span className="subscription-tag">{customer.subscription}</span></td>
                          <td>{formatDate(customer.since)}</td>
                          <td>{formatDate(customer.lastOrder)}</td>
                          <td className="num-col">{formatCurrency(customer.lifetimeValue)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          )}

          <p className="sample-note">Sample records for demonstration — data persists locally on this server.</p>
        </>
      )}
    </div>
  );
}