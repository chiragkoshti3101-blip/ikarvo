import { NextRequest, NextResponse } from 'next/server';
import { getOrders, getCustomers, addOrder, addCustomer, updateOrderStatus } from '../../../lib/store';

const ORDER_STATUSES = ['pending', 'roasting', 'packed', 'shipped', 'delivered'] as const;
const ROAST_LEVELS = ['light', 'medium', 'dark'] as const;

function getResource(request: NextRequest): 'orders' | 'customers' | null {
  const resource = new URL(request.url).searchParams.get('resource');
  return resource === 'orders' || resource === 'customers' ? resource : null;
}

async function readBody(request: NextRequest): Promise<Record<string, unknown> | null> {
  try {
    const body = await request.json();
    return typeof body === 'object' && body !== null ? (body as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

export async function GET(request: NextRequest) {
  const resource = getResource(request);
  if (!resource) {
    return NextResponse.json({ error: 'Missing or invalid resource query parameter' }, { status: 400 });
  }
  try {
    if (resource === 'orders') {
      return NextResponse.json({ orders: await getOrders() });
    }
    return NextResponse.json({ customers: await getCustomers() });
  } catch {
    return NextResponse.json({ error: 'Failed to read data' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const resource = getResource(request);
  if (!resource) {
    return NextResponse.json({ error: 'Missing or invalid resource query parameter' }, { status: 400 });
  }

  const body = await readBody(request);
  if (!body) {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  if (resource === 'orders') {
    const errors: string[] = [];
    if (typeof body.customerId !== 'string' || !body.customerId.trim()) {
      errors.push('customerId is required');
    }
    if (typeof body.roastLevel !== 'string' || !ROAST_LEVELS.includes(body.roastLevel as (typeof ROAST_LEVELS)[number])) {
      errors.push('roastLevel must be light, medium, or dark');
    }
    if (typeof body.bagSize !== 'number' || body.bagSize <= 0) {
      errors.push('bagSize must be a positive number');
    }
    if (typeof body.quantity !== 'number' || body.quantity < 1 || !Number.isInteger(body.quantity)) {
      errors.push('quantity must be a positive integer');
    }
    if (typeof body.total !== 'number' || body.total < 0) {
      errors.push('total must be a non-negative number');
    }
    if (body.status !== undefined && (typeof body.status !== 'string' || !ORDER_STATUSES.includes(body.status as (typeof ORDER_STATUSES)[number]))) {
      errors.push('status is invalid');
    }
    if (errors.length) {
      return NextResponse.json({ error: errors.join('; ') }, { status: 400 });
    }

    try {
      const order = await addOrder({
        customerId: body.customerId.trim(),
        roastLevel: body.roastLevel as string,
        bagSize: body.bagSize,
        quantity: body.quantity,
        total: body.total,
        status: (body.status as string) || 'pending',
      });
      return NextResponse.json({ order }, { status: 201 });
    } catch {
      return NextResponse.json({ error: 'Failed to save order' }, { status: 500 });
    }
  }

  const errors: string[] = [];
  if (typeof body.name !== 'string' || !body.name.trim()) {
    errors.push('name is required');
  }
  if (typeof body.email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
    errors.push('a valid email is required');
  }
  if (errors.length) {
    return NextResponse.json({ error: errors.join('; ') }, { status: 400 });
  }

  try {
    const customer = await addCustomer({
      name: body.name.trim(),
      email: body.email.trim().toLowerCase(),
      phone: typeof body.phone === 'string' ? body.phone.trim() : undefined,
      address: typeof body.address === 'string' ? body.address.trim() : undefined,
    });
    return NextResponse.json({ customer }, { status: 201 });
  } catch {
    return NextResponse.json({ error: 'Failed to save customer' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const resource = getResource(request);
  if (!resource) {
    return NextResponse.json({ error: 'Missing or invalid resource query parameter' }, { status: 400 });
  }

  const body = await readBody(request);
  if (!body) {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  if (resource === 'orders') {
    if (typeof body.id !== 'string' || !body.id.trim()) {
      return NextResponse.json({ error: 'id is required' }, { status: 400 });
    }
    if (typeof body.status !== 'string' || !ORDER_STATUSES.includes(body.status as (typeof ORDER_STATUSES)[number])) {
      return NextResponse.json({ error: 'A valid status is required' }, { status: 400 });
    }

    try {
      const updated = await updateOrderStatus(body.id.trim(), body.status);
      if (!updated) {
        return NextResponse.json({ error: 'Order not found' }, { status: 404 });
      }
      return NextResponse.json({ order: updated });
    } catch {
      return NextResponse.json({ error: 'Failed to update order' }, { status: 500 });
    }
  }

  return NextResponse.json({ error: 'Customer updates are not supported' }, { status: 400 });
}