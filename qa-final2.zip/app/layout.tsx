import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Ember & Oak — Order Desk",
  description: "Subscription order desk for Ember & Oak small-batch coffee roastery.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <div className="shell">
          <aside className="sidebar">
            <div className="brand">
              <span className="brand-mark" aria-hidden="true"></span>
              <span className="brand-name">Ember &amp; Oak</span>
              <span className="brand-sub">Roastery Order Desk</span>
            </div>
            <nav className="sidebar-nav" aria-label="Primary">
              <a className="nav-link nav-link-active" href="/" aria-current="page">
                Orders
              </a>
              <a className="nav-link" href="/customers">
                Customers
              </a>
            </nav>
            <div className="sidebar-foot">
              <span className="foot-label">This week</span>
              <span className="foot-value">Sample data</span>
            </div>
          </aside>
          <main className="main">{children}</main>
        </div>
      </body>
    </html>
  );
}