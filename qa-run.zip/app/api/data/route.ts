import { NextRequest, NextResponse } from 'next/server';
import { readStore, writeStore, Order, Customer } from '../../lib/store';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');

  if (type === 'orders') {
    const orders = readStore().orders;
    return NextResponse.json({ orders });
  }

  if (type === 'customers') {
    const customers = readStore().customers;
    return NextResponse.json({ customers });
  }

  return NextResponse.json({ error: 'type is required (orders or customers)' }, { status: 400 });
}

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== 'object') {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 });
  }

  const type = body.type;
  if (type !== 'orders' && type !== 'customers') {
    return NextResponse.json({ error: 'type must be "orders" or "customers"' }, { status: 400 });
  }

  if (type === 'orders') {
    if (typeof body.customerId !== 'string' || !body.customerId.trim()) {
      return NextResponse.json({ error: 'customerId is required' }, { status: 400 });
    }
    if (typeof body.customerName !== 'string' || !body.customerName.trim()) {
      return NextResponse.json({ error: 'customerName is required' }, { status: 400 });
    }
    if (typeof body.bagCount !== 'number' || body.bagCount <= 0) {
      return NextResponse.json({ error: 'bagCount must be a positive number' }, { status: 400 });
    }
    if (typeof body.revenue !== 'number' || body.revenue < 0) {
      return NextResponse.json({ error: 'revenue must be a non-negative number' }, { status: 400 });
    }
    if (typeof body.status !== 'string' || !['pending', 'roasting', 'packed', 'shipped'].includes(body.status)) {
      return NextResponse.json({ error: 'status must be pending, roasting, packed, or shipped' }, { status: 400 });
    }
    if (typeof body.deliveryDate !== 'string' || !body.deliveryDate.trim()) {
      return NextResponse.json({ error: 'deliveryDate is required' }, { status: 400 });
    }
    if (typeof body.roastBatch !== 'string' || !body.roastBatch.trim()) {
      return NextResponse.json({ error: 'roastBatch is required' }, { status: 400 });
    }

    const store = readStore();
    const order: Order = {
      id: `ord_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      customerId: body.customerId.trim(),
      customerName: body.customerName.trim(),
      bagCount: body.bagCount,
      revenue: body.revenue,
      status: body.status,
      deliveryDate: body.deliveryDate.trim(),
      roastBatch: body.roastBatch.trim(),
    };
    store.orders.unshift(order);
    await writeStore(store);
    return NextResponse.json({ order }, { status: 201 });
  }

  if (typeof body.name !== 'string' || !body.name.trim()) {
    return NextResponse.json({ error: 'name is required' }, { status: 400 });
  }
  if (typeof body.email !== 'string' || !body.email.trim() || !body.email.includes('@')) {
    return NextResponse.json({ error: 'a valid email is required' }, { status: 400 });
  }
  if (typeof body.phone !== 'string' || !body.phone.trim()) {
    return NextResponse.json({ error: 'phone is required' }, { status: 400 });
  }
  if (typeof body.subscriptionTier !== 'string' || !body.subscriptionTier.trim()) {
    return NextResponse.json({ error: 'subscriptionTier is required' }, { status: 400 });
  }
  if (typeof body.status !== 'string' || !['active', 'paused', 'cancelled'].includes(body.status)) {
    return NextResponse.json({ error: 'status must be active, paused, or cancelled' }, { status: 400 });
  }

  const store = readStore();
  const customer: Customer = {
    id: `cus_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    name: body.name.trim(),
    email: body.email.trim(),
    phone: body.phone.trim(),
    subscriptionTier: body.subscriptionTier.trim(),
    status: body.status,
    joinDate: new Date().toISOString().slice(0, 10),
  };
  store.customers.unshift(customer);
  await writeStore(store);
  return NextResponse.json({ customer }, { status: 201 });
}

export async function PUT(request: NextRequest) {
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== 'object') {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 });
  }

  const type = body.type;
  if (type !== 'orders' && type !== 'customers') {
    return NextResponse.json({ error: 'type must be "orders" or "customers"' }, { status: 400 });
  }

  if (typeof body.id !== 'string' || !body.id.trim()) {
    return NextResponse.json({ error: 'id is required' }, { status: 400 });
  }

  const store = readStore();

  if (type === 'orders') {
    const order = store.orders.find((o) => o.id === body.id);
    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }
    if (typeof body.status !== 'string' || !['pending', 'roasting', 'packed', 'shipped'].includes(body.status)) {
      return NextResponse.json({ error: 'status must be pending, roasting, packed, or shipped' }, { status: 400 });
    }
    order.status = body.status;
    await writeStore(store);
    return NextResponse.json({ order });
  }

  const customer = store.customers.find((c) => c.id === body.id);
  if (!customer) {
    return NextResponse.json({ error: 'Customer not found' }, { status: 404 });
  }
  if (typeof body.status !== 'string' || !['active', 'paused', 'cancelled'].includes(body.status)) {
    return NextResponse.json({ error: 'status must be active, paused, or cancelled' }, { status: 400 });
  }
  customer.status = body.status;
  await writeStore(store);
  return NextResponse.json({ customer });
}