import './globals.css';
import Link from 'next/link';
import type { ReactNode } from 'react';

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="shell">
          <aside className="sidebar">
            <div className="sidebar-brand">
              <span className="brand-mark" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22c4.4 0 8-3.6 8-8 0-5-4-9-8-12-4 3-8 7-8 12 0 4.4 3.6 8 8 8z" />
                  <path d="M12 22c-2.2 0-4-1.8-4-4 0-2.5 2-4.5 4-6 2 1.5 4 3.5 4 6 0 2.2-1.8 4-4 4z" />
                </svg>
              </span>
              <div className="brand-text">
                <span className="brand-name">Ember &amp; Oak</span>
                <span className="brand-sub">Small-batch roastery</span>
              </div>
            </div>
            <nav className="sidebar-nav" aria-label="Main navigation">
              <Link href="/" className="sidebar-nav-item active">Order Desk</Link>
              <Link href="/" className="sidebar-nav-item">Customers</Link>
            </nav>
            <div className="sidebar-footer">
              <span className="sample-badge">Sample records — replace before going live</span>
            </div>
          </aside>
          <main className="main">{children}</main>
        </div>
      </body>
    </html>
  );
}