'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';

type OrderStatus = 'pending' | 'roasting' | 'packed' | 'shipped';
type CustomerStatus = 'active' | 'paused' | 'cancelled';

type Order = {
  id: string;
  customerId: string;
  customerName: string;
  bagCount: number;
  revenue: number;
  status: OrderStatus;
  deliveryDate: string;
  roastBatch: string;
};

type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string;
  subscriptionTier: string;
  status: CustomerStatus;
  joinDate: string;
};

type OrderSortKey = 'customerName' | 'bagCount' | 'revenue' | 'status' | 'deliveryDate' | 'roastBatch';
type CustomerSortKey = 'name' | 'email' | 'subscriptionTier' | 'status' | 'joinDate';

const ORDER_STATUSES: OrderStatus[] = ['pending', 'roasting', 'packed', 'shipped'];
const CUSTOMER_STATUSES: CustomerStatus[] = ['active', 'paused', 'cancelled'];

const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending',
  roasting: 'Roasting',
  packed: 'Packed',
  shipped: 'Shipped',
};

const CUSTOMER_STATUS_LABELS: Record<CustomerStatus, string> = {
  active: 'Active',
  paused: 'Paused',
  cancelled: 'Cancelled',
};

const ORDER_SORT_LABELS: Record<OrderSortKey, string> = {
  customerName: 'Customer',
  bagCount: 'Bags',
  revenue: 'Revenue',
  status: 'Status',
  deliveryDate: 'Delivery',
  roastBatch: 'Batch',
};

const CUSTOMER_SORT_LABELS: Record<CustomerSortKey, string> = {
  name: 'Name',
  email: 'Email',
  subscriptionTier: 'Tier',
  status: 'Status',
  joinDate: 'Joined',
};

function formatCurrency(value: number): string {
  return value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
}

function formatDate(value: string): string {
  const date = new Date(value + 'T00:00:00');
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function getOrderSortValue(order: Order, key: OrderSortKey): string | number {
  return order[key];
}

function getCustomerSortValue(customer: Customer, key: CustomerSortKey): string | number {
  return customer[key];
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<'orders' | 'customers'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [customersLoading, setCustomersLoading] = useState(true);
  const [ordersError, setOrdersError] = useState<string | null>(null);
  const [customersError, setCustomersError] = useState<string | null>(null);

  const [orderSearch, setOrderSearch] = useState('');
  const [customerSearch, setCustomerSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [customerStatusFilter, setCustomerStatusFilter] = useState<CustomerStatus | 'all'>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [orderSortKey, setOrderSortKey] = useState<OrderSortKey>('deliveryDate');
  const [orderSortDir, setOrderSortDir] = useState<'asc' | 'desc'>('asc');
  const [customerSortKey, setCustomerSortKey] = useState<CustomerSortKey>('name');
  const [customerSortDir, setCustomerSortDir] = useState<'asc' | 'desc'>('asc');
  const [exportMessage, setExportMessage] = useState<string | null>(null);

  const loadOrders = useCallback(async () => {
    setOrdersLoading(true);
    setOrdersError(null);
    try {
      const res = await fetch('/api/data?type=orders');
      if (!res.ok) throw new Error('Failed to load orders');
      const data = await res.json();
      setOrders(data.orders);
    } catch {
      setOrdersError('Could not load orders. Please try again.');
    } finally {
      setOrdersLoading(false);
    }
  }, []);

  const loadCustomers = useCallback(async () => {
    setCustomersLoading(true);
    setCustomersError(null);
    try {
      const res = await fetch('/api/data?type=customers');
      if (!res.ok) throw new Error('Failed to load customers');
      const data = await res.json();
      setCustomers(data.customers);
    } catch {
      setCustomersError('Could not load customers. Please try again.');
    } finally {
      setCustomersLoading(false);
    }
  }, []);

  useEffect(() => {
    loadOrders();
    loadCustomers();
  }, [loadOrders, loadCustomers]);

  const filteredOrders = useMemo(() => {
    let result = orders;
    if (orderStatusFilter !== 'all') {
      result = result.filter((o) => o.status === orderStatusFilter);
    }
    if (dateFrom) {
      result = result.filter((o) => o.deliveryDate >= dateFrom);
    }
    if (dateTo) {
      result = result.filter((o) => o.deliveryDate <= dateTo);
    }
    if (orderSearch.trim()) {
      const q = orderSearch.trim().toLowerCase();
      result = result.filter(
        (o) =>
          o.customerName.toLowerCase().includes(q) ||
          o.roastBatch.toLowerCase().includes(q) ||
          o.id.toLowerCase().includes(q)
      );
    }
    const dir = orderSortDir === 'asc' ? 1 : -1;
    result = [...result].sort((a, b) => {
      const av = getOrderSortValue(a, orderSortKey);
      const bv = getOrderSortValue(b, orderSortKey);
      if (typeof av === 'string' && typeof bv === 'string') {
        return av.localeCompare(bv) * dir;
      }
      return ((av as number) - (bv as number)) * dir;
    });
    return result;
  }, [orders, orderStatusFilter, dateFrom, dateTo, orderSearch, orderSortKey, orderSortDir]);

  const filteredCustomers = useMemo(() => {
    let result = customers;
    if (customerStatusFilter !== 'all') {
      result = result.filter((c) => c.status === customerStatusFilter);
    }
    if (customerSearch.trim()) {
      const q = customerSearch.trim().toLowerCase();
      result = result.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.email.toLowerCase().includes(q) ||
          c.phone.toLowerCase().includes(q) ||
          c.subscriptionTier.toLowerCase().includes(q)
      );
    }
    const dir = customerSortDir === 'asc' ? 1 : -1;
    result = [...result].sort((a, b) => {
      const av = getCustomerSortValue(a, customerSortKey);
      const bv = getCustomerSortValue(b, customerSortKey);
      if (typeof av === 'string' && typeof bv === 'string') {
        return av.localeCompare(bv) * dir;
      }
      return ((av as number) - (bv as number)) * dir;
    });
    return result;
  }, [customers, customerStatusFilter, customerSearch, customerSortKey, customerSortDir]);

  const kpis = useMemo(() => {
    const weekOrders = orders.filter((o) => {
      const d = new Date(o.deliveryDate + 'T00:00:00');
      const now = new Date();
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - now.getDay());
      weekStart.setHours(0, 0, 0, 0);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      weekEnd.setHours(23, 59, 59, 999);
      return d >= weekStart && d <= weekEnd;
    });
    const revenue = weekOrders.reduce((sum, o) => sum + o.revenue, 0);
    const openOrders = orders.filter((o) => o.status === 'pending' || o.status === 'roasting').length;
    const bags = orders.reduce((sum, o) => sum + o.bagCount, 0);
    const batches = new Set(orders.map((o) => o.roastBatch)).size;
    return { revenue, openOrders, bags, batches };
  }, [orders]);

  const handleOrderStatusChange = useCallback(
    async (orderId: string, newStatus: OrderStatus) => {
      const previous = orders;
      setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status: newStatus } : o)));
      try {
        const res = await fetch('/api/data', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'orders', id: orderId, status: newStatus }),
        });
        if (!res.ok) throw new Error('Failed to update order');
        const data = await res.json();
        setOrders((prev) => prev.map((o) => (o.id === orderId ? data.order : o)));
      } catch {
        setOrders(previous);
        setOrdersError('Could not update order status. Please try again.');
      }
    },
    [orders]
  );

  const handleCustomerStatusChange = useCallback(
    async (customerId: string, newStatus: CustomerStatus) => {
      const previous = customers;
      setCustomers((prev) => prev.map((c) => (c.id === customerId ? { ...c, status: newStatus } : c)));
      try {
        const res = await fetch('/api/data', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'customers', id: customerId, status: newStatus }),
        });
        if (!res.ok) throw new Error('Failed to update customer');
        const data = await res.json();
        setCustomers((prev) => prev.map((c) => (c.id === customerId ? data.customer : c)));
      } catch {
        setCustomers(previous);
        setCustomersError('Could not update customer status. Please try again.');
      }
    },
    [customers]
  );

  const handleExport = useCallback(() => {
    const rows = activeTab === 'orders' ? filteredOrders : filteredCustomers;
    if (rows.length === 0) {
      setExportMessage('Nothing to export — the current view is empty.');
      return;
    }
    const headers =
      activeTab === 'orders'
        ? ['Order ID', 'Customer', 'Bags', 'Revenue', 'Status', 'Delivery Date', 'Roast Batch']
        : ['Customer ID', 'Name', 'Email', 'Phone', 'Tier', 'Status', 'Joined'];
    const lines = rows.map((row) => {
      if (activeTab === 'orders') {
        const o = row as Order;
        return [o.id, o.customerName, String(o.bagCount), o.revenue.toFixed(2), ORDER_STATUS_LABELS[o.status], o.deliveryDate, o.roastBatch];
      }
      const c = row as Customer;
      return [c.id, c.name, c.email, c.phone, c.subscriptionTier, CUSTOMER_STATUS_LABELS[c.status], c.joinDate];
    });
    const csv = [headers, ...lines]
      .map((line) => line.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeTab === 'orders' ? 'ember-oak-orders.csv' : 'ember-oak-customers.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setExportMessage(`Exported ${rows.length} ${activeTab === 'orders' ? 'orders' : 'customers'} to CSV.`);
    window.setTimeout(() => setExportMessage(null), 3000);
  }, [activeTab, filteredOrders, filteredCustomers]);

  const toggleOrderSort = (key: OrderSortKey) => {
    if (key === orderSortKey) {
      setOrderSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setOrderSortKey(key);
      setOrderSortDir('asc');
    }
  };

  const toggleCustomerSort = (key: CustomerSortKey) => {
    if (key === customerSortKey) {
      setCustomerSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setCustomerSortKey(key);
      setCustomerSortDir('asc');
    }
  };

  const clearOrderFilters = () => {
    setOrderSearch('');
    setOrderStatusFilter('all');
    setDateFrom('');
    setDateTo('');
  };

  const clearCustomerFilters = () => {
    setCustomerSearch('');
    setCustomerStatusFilter('all');
  };

  const hasOrderFilters = orderSearch !== '' || orderStatusFilter !== 'all' || dateFrom !== '' || dateTo !== '';
  const hasCustomerFilters = customerSearch !== '' || customerStatusFilter !== 'all';

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-block">
          <span className="brand-mark">E&O</span>
          <div>
            <p className="brand-name">Ember &amp; Oak</p>
            <p className="brand-sub">Roastery Order Desk</p>
          </div>
        </div>
        <nav className="sidebar-nav" aria-label="Main navigation">
          <button
            type="button"
            className={`nav-item ${activeTab === 'orders' ? 'nav-item-active' : ''}`}
            onClick={() => setActiveTab('orders')}
          >
            Orders
          </button>
          <button
            type="button"
            className={`nav-item ${activeTab === 'customers' ? 'nav-item-active' : ''}`}
            onClick={() => setActiveTab('customers')}
          >
            Customers
          </button>
        </nav>
        <div className="sidebar-footer">
          <p className="sample-note">Sample records — replace before going live</p>
        </div>
      </aside>

      <main className="main-content">
        <header className="page-header">
          <div>
            <h1 className="page-title">{activeTab === 'orders' ? 'This Week’s Subscription Orders' : 'Customers'}</h1>
            <p className="page-subtitle">
              {activeTab === 'orders'
                ? 'Track roast batches, delivery dates, and order status for the week ahead.'
                : 'Manage subscriber details, tiers, and account status.'}
            </p>
          </div>
          <button type="button" className="export-button" onClick={handleExport}>
            Export CSV
          </button>
        </header>

        {exportMessage && <p className="export-message" role="status">{exportMessage}</p>}

        <section className="kpi-row" aria-label="Key metrics">
          <div className="kpi-card">
            <p className="kpi-label">Week Revenue</p>
            <p className="kpi-value">{formatCurrency(kpis.revenue)}</p>
          </div>
          <div className="kpi-card">
            <p className="kpi-label">Open Orders</p>
            <p className="kpi-value">{kpis.openOrders}</p>
          </div>
          <div className="kpi-card">
            <p className="kpi-label">Total Bags</p>
            <p className="kpi-value">{kpis.bags}</p>
          </div>
          <div className="kpi-card">
            <p className="kpi-label">Roast Batches</p>
            <p className="kpi-value">{kpis.batches}</p>
          </div>
        </section>

        {activeTab === 'orders' ? (
          <section className="table-section" aria-label="Orders">
            <div className="filter-bar">
              <div className="filter-group">
                <label className="filter-label" htmlFor="order-search">Search</label>
                <input
                  id="order-search"
                  type="search"
                  className="filter-input"
                  placeholder="Customer, batch, or order ID"
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                />
              </div>
              <div className="filter-group">
                <span className="filter-label">Status</span>
                <div className="filter-chips" role="group" aria-label="Filter orders by status">
                  <button
                    type="button"
                    className={`chip ${orderStatusFilter === 'all' ? 'chip-active' : ''}`}
                    onClick={() => setOrderStatusFilter('all')}
                  >
                    All
                  </button>
                  {ORDER_STATUSES.map((s) => (
                    <button
                      key={s}
                      type="button"
                      className={`chip ${orderStatusFilter === s ? 'chip-active' : ''}`}
                      onClick={() => setOrderStatusFilter(s)}
                    >
                      {ORDER_STATUS_LABELS[s]}
                    </button>
                  ))}
                </div>
              </div>
              <div className="filter-group">
                <label className="filter-label" htmlFor="date-from">From</label>
                <input
                  id="date-from"
                  type="date"
                  className="filter-input filter-date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                />
              </div>
              <div className="filter-group">
                <label className="filter-label" htmlFor="date-to">To</label>
                <input
                  id="date-to"
                  type="date"
                  className="filter-input filter-date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                />
              </div>
              {hasOrderFilters && (
                <button type="button" className="clear-filters" onClick={clearOrderFilters}>
                  Clear filters
                </button>
              )}
            </div>

            {ordersLoading ? (
              <div className="state-block" role="status">
                <p className="state-text">Loading orders…</p>
              </div>
            ) : ordersError ? (
              <div className="state-block state-error" role="alert">
                <p className="state-text">{ordersError}</p>
                <button type="button" className="retry-button" onClick={loadOrders}>
                  Try again
                </button>
              </div>
            ) : filteredOrders.length === 0 ? (
              <div className="state-block">
                <p className="state-title">No orders match your filters</p>
                <p className="state-text">
                  {orders.length === 0 ? 'There are no orders yet. New orders will appear here.' : 'Try adjusting your search or clearing the filters.'}
                </p>
                {hasOrderFilters && (
                  <button type="button" className="retry-button" onClick={clearOrderFilters}>
                    Clear filters
                  </button>
                )}
              </div>
            ) : (
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      {(Object.keys(ORDER_SORT_LABELS) as OrderSortKey[]).map((key) => (
                        <th key={key} scope="col">
                          <button
                            type="button"
                            className={`sort-button ${orderSortKey === key ? 'sort-active' : ''}`}
                            onClick={() => toggleOrderSort(key)}
                            aria-sort={orderSortKey === key ? (orderSortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
                          >
                            {ORDER_SORT_LABELS[key]}
                            {orderSortKey === key && <span className="sort-arrow">{orderSortDir === 'asc' ? '↑' : '↓'}</span>}
                          </button>
                        </th>
                      ))}
                      <th scope="col">Update Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredOrders.map((order) => (
                      <tr key={order.id}>
                        <td className="cell-primary">{order.customerName}</td>
                        <td>{order.bagCount}</td>
                        <td>{formatCurrency(order.revenue)}</td>
                        <td>
                          <span className={`status-badge status-${order.status}`}>
                            {ORDER_STATUS_LABELS[order.status]}
                          </span>
                        </td>
                        <td>{formatDate(order.deliveryDate)}</td>
                        <td>
                          <span className="batch-code">{order.roastBatch}</span>
                        </td>
                        <td>
                          <select
                            className="status-select"
                            value={order.status}
                            onChange={(e) => handleOrderStatusChange(order.id, e.target.value as OrderStatus)}
                            aria-label={`Update status for ${order.customerName}`}
                          >
                            {ORDER_STATUSES.map((s) => (
                              <option key={s} value={s}>
                                {ORDER_STATUS_LABELS[s]}
                              </option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        ) : (
          <section className="table-section" aria-label="Customers">
            <div className="filter-bar">
              <div className="filter-group">
                <label className="filter-label" htmlFor="customer-search">Search</label>
                <input
                  id="customer-search"
                  type="search"
                  className="filter-input"
                  placeholder="Name, email, phone, or tier"
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                />
              </div>
              <div className="filter-group">
                <span className="filter-label">Status</span>
                <div className="filter-chips" role="group" aria-label="Filter customers by status">
                  <button
                    type="button"
                    className={`chip ${customerStatusFilter === 'all' ? 'chip-active' : ''}`}
                    onClick={() => setCustomerStatusFilter('all')}
                  >
                    All
                  </button>
                  {CUSTOMER_STATUSES.map((s) => (
                    <button
                      key={s}
                      type="button"
                      className={`chip ${customerStatusFilter === s ? 'chip-active' : ''}`}
                      onClick={() => setCustomerStatusFilter(s)}
                    >
                      {CUSTOMER_STATUS_LABELS[s]}
                    </button>
                  ))}
                </div>
              </div>
              {hasCustomerFilters && (
                <button type="button" className="clear-filters" onClick={clearCustomerFilters}>
                  Clear filters
                </button>
              )}
            </div>

            {customersLoading ? (
              <div className="state-block" role="status">
                <p className="state-text">Loading customers…</p>
              </div>
            ) : customersError ? (
              <div className="state-block state-error" role="alert">
                <p className="state-text">{customersError}</p>
                <button type="button" className="retry-button" onClick={loadCustomers}>
                  Try again
                </button>
              </div>
            ) : filteredCustomers.length === 0 ? (
              <div className="state-block">
                <p className="state-title">No customers match your filters</p>
                <p className="state-text">
                  {customers.length === 0 ? 'There are no customers yet. New customers will appear here.' : 'Try adjusting your search or clearing the filters.'}
                </p>
                {hasCustomerFilters && (
                  <button type="button" className="retry-button" onClick={clearCustomerFilters}>
                    Clear filters
                  </button>
                )}
              </div>
            ) : (
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      {(Object.keys(CUSTOMER_SORT_LABELS) as CustomerSortKey[]).map((key) => (
                        <th key={key} scope="col">
                          <button
                            type="button"
                            className={`sort-button ${customerSortKey === key ? 'sort-active' : ''}`}
                            onClick={() => toggleCustomerSort(key)}
                            aria-sort={customerSortKey === key ? (customerSortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
                          >
                            {CUSTOMER_SORT_LABELS[key]}
                            {customerSortKey === key && <span className="sort-arrow">{customerSortDir === 'asc' ? '↑' : '↓'}</span>}
                          </button>
                        </th>
                      ))}
                      <th scope="col">Update Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCustomers.map((customer) => (
                      <tr key={customer.id}>
                        <td className="cell-primary">{customer.name}</td>
                        <td>{customer.email}</td>
                        <td>{customer.phone}</td>
                        <td>{customer.subscriptionTier}</td>
                        <td>
                          <span className={`status-badge status-${customer.status}`}>
                            {CUSTOMER_STATUS_LABELS[customer.status]}
                          </span>
                        </td>
                        <td>{formatDate(customer.joinDate)}</td>
                        <td>
                          <select
                            className="status-select"
                            value={customer.status}
                            onChange={(e) => handleCustomerStatusChange(customer.id, e.target.value as CustomerStatus)}
                            aria-label={`Update status for ${customer.name}`}
                          >
                            {CUSTOMER_STATUSES.map((s) => (
                              <option key={s} value={s}>
                                {CUSTOMER_STATUS_LABELS[s]}
                              </option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}
      </main>
    </div>
  );
}