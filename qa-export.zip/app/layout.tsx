import './globals.css';
import Link from 'next/link';
import { ReactNode } from 'react';

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <title>Ember & Oak – Order Desk</title>
        <meta name="description" content="Dashboard for subscription orders, customers, and roast batches." />
      </head>
      <body className="shell">
        <aside className="sidebar">
          <nav>
            <ul>
              <li><Link href="/" className="nav-link">Dashboard</Link></li>
              <li><Link href="/orders" className="nav-link">Orders</Link></li>
              <li><Link href="/customers" className="nav-link">Customers</Link></li>
              <li><Link href="/settings" className="nav-link">Settings</Link></li>
            </ul>
          </nav>
        </aside>
        <main className="main">{children}</main>
      </body>
    </html>
  );
}