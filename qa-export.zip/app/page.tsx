'use client';
import { useState, useEffect } from 'react';
import { Order, Customer, OrderStatus } from '../lib/store';

type Tab = 'orders' | 'customers';

interface SortConfig<T> {
  key: keyof T;
  direction: 'asc' | 'desc';
}

export default function DashboardPage() {
  const [tab, setTab] = useState<Tab>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [orderSort, setOrderSort] = useState<SortConfig<Order> | null>(null);
  const [customerSort, setCustomerSort] = useState<SortConfig<Customer> | null>(null);

  useEffect(() => {
    async function loadData() {
      try {
        const [ordersRes, customersRes] = await Promise.all([
          fetch('/api/orders'),
          fetch('/api/customers'),
        ]);
        if (!ordersRes.ok || !customersRes.ok) throw new Error('Failed to load data');
        const ordersData: Order[] = await ordersRes.json();
        const customersData: Customer[] = await customersRes.json();
        setOrders(ordersData);
        setCustomers(customersData);
        setError(null);
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.batchNumber.toLowerCase().includes(search.toLowerCase()) ||
      o.roastLevel.toLowerCase().includes(search.toLowerCase()) ||
      o.status.toLowerCase().includes(search.toLowerCase());
    const created = new Date(o.createdAt);
    const from = dateFrom ? new Date(dateFrom) : null;
    const to = dateTo ? new Date(dateTo) : null;
    const matchesDate =
      (!from || created >= from) && (!to || created <= to);
    return matchesSearch && matchesDate;
  });

  const sortedOrders = [...filteredOrders].sort((a, b) => {
    if (!orderSort) return 0;
    const aVal = a[orderSort.key];
    const bVal = b[orderSort.key];
    if (aVal < bVal) return orderSort.direction === 'asc' ? -1 : 1;
    if (aVal > bVal) return orderSort.direction === 'asc' ? 1 : -1;
    return 0;
  });

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.toLowerCase().includes(search.toLowerCase()) ||
      c.subscriptionTier.toLowerCase().includes(search.toLowerCase());
    return matchesSearch;
  });

  const sortedCustomers = [...filteredCustomers].sort((a, b) => {
    if (!customerSort) return 0;
    const aVal = a[customerSort.key];
    const bVal = b[customerSort.key];
    if (aVal < bVal) return customerSort.direction === 'asc' ? -1 : 1;
    if (aVal > bVal) return customerSort.direction === 'asc' ? 1 : -1;
    return 0;
  });

  const revenue = orders.reduce((sum, o) => sum + o.total, 0);
  const openOrders = orders.filter((o) => o.status !== 'delivered').length;
  const totalBags = orders.reduce((sum, o) => sum + o.items.reduce((iSum, i) => iSum + i.quantity, 0), 0);
  const distinctBatches = new Set(orders.map((o) => o.batchNumber)).size;

  const exportCSV = () => {
    const rows = tab === 'orders' ? sortedOrders : sortedCustomers;
    const headers = tab === 'orders'
      ? ['ID', 'Customer', 'Created', 'Delivery', 'Status', 'Batch', 'Roast', 'Total']
      : ['ID', 'Name', 'Email', 'Phone', 'Tier', 'Frequency', 'Join Date', 'Active'];
    const csvContent = [
      headers.join(','),
      ...rows.map((r) => {
        if (tab === 'orders') {
          const o = r as Order;
          const cust = customers.find((c) => c.id === o.customerId);
          return [
            o.id,
            cust?.name ?? '',
            o.createdAt,
            o.deliveryDate,
            o.status,
            o.batchNumber,
            o.roastLevel,
            o.total.toFixed(2),
          ].join(',');
        } else {
          const c = r as Customer;
          return [
            c.id,
            c.name,
            c.email,
            c.phone,
            c.subscriptionTier,
            c.frequency,
            c.joinDate,
            c.active ? 'Yes' : 'No',
          ].join(',');
        }
      }),
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${tab}_export_${new Date().toISOString()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const updateStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (!res.ok) throw new Error('Failed to update status');
      const updated: Order = await res.json();
      setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
    } catch (e) {
      alert('Error updating status');
    }
  };

  if (loading) return <div className="shell">Loading…</div>;
  if (error) return <div className="shell error-state">Error: {error}</div>;

  return (
    <div className="shell">
      <header className="header">
        <h1>Ember &amp; Oak – Subscription Dashboard</h1>
        <p className="sample-note">Sample data loaded – changes persist locally.</p>
      </header>

      <section className="kpi-row">
        <div className="kpi-card"><strong>Revenue</strong><br/>${revenue.toFixed(2)}</div>
        <div className="kpi-card"><strong>Open Orders</strong><br/>{openOrders}</div>
        <div className="kpi-card"><strong>Total Bags</strong><br/>{totalBags}</div>
        <div className="kpi-card"><strong>Batches</strong><br/>{distinctBatches}</div>
      </section>

      <nav className="tabs">
        <button className={`tab ${tab === 'orders' ? 'active-tab' : ''}`} onClick={() => setTab('orders')}>Orders</button>
        <button className={`tab ${tab === 'customers' ? 'active-tab' : ''}`} onClick={() => setTab('customers')}>Customers</button>
      </nav>

      <section className="filter-bar">
        <input
          type="text"
          className="search-input"
          placeholder="Search…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {tab === 'orders' && (
          <>
            <input type="date" className="date-input" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            <input type="date" className="date-input" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
          </>
        )}
        <button className="export-button" onClick={exportCSV}>Export CSV</button>
      </section>

      {tab === 'orders' && (
        <table className="data-table">
          <thead>
            <tr className="table-header">
              <th onClick={() => setOrderSort({ key: 'id', direction: orderSort?.direction === 'asc' ? 'desc' : 'asc' })}>ID</th>
              <th>Customer</th>
              <th onClick={() => setOrderSort({ key: 'createdAt', direction: orderSort?.direction === 'asc' ? 'desc' : 'asc' })}>Created</th>
              <th onClick={() => setOrderSort({ key: 'deliveryDate', direction: orderSort?.direction === 'asc' ? 'desc' : 'asc' })}>Delivery</th>
              <th>Status</th>
              <th>Batch</th>
              <th>Roast</th>
              <th onClick={() => setOrderSort({ key: 'total', direction: orderSort?.direction === 'asc' ? 'desc' : 'asc' })}>Total</th>
            </tr>
          </thead>
          <tbody>
            {sortedOrders.length === 0 ? (
              <tr className="empty-state"><td colSpan={8}>No orders match the criteria.</td></tr>
            ) : (
              sortedOrders.map((o) => {
                const cust = customers.find((c) => c.id === o.customerId);
                return (
                  <tr key={o.id} className="table-row">
                    <td className="table-cell">{o.id}</td>
                    <td className="table-cell">{cust?.name ?? '—'}</td>
                    <td className="table-cell">{new Date(o.createdAt).toLocaleDateString()}</td>
                    <td className="table-cell">{new Date(o.deliveryDate).toLocaleDateString()}</td>
                    <td className="table-cell">
                      <select
                        className="status-select"
                        value={o.status}
                        onChange={(e) => updateStatus(o.id, e.target.value as OrderStatus)}
                      >
                        <option value="pending">Pending</option>
                        <option value="roasting">Roasting</option>
                        <option value="packed">Packed</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                      </select>
                    </td>
                    <td className="table-cell">{o.batchNumber}</td>
                    <td className="table-cell">{o.roastLevel}</td>
                    <td className="table-cell">${o.total.toFixed(2)}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      )}

      {tab === 'customers' && (
        <table className="data-table">
          <thead>
            <tr className="table-header">
              <th onClick={() => setCustomerSort({ key: 'id', direction: customerSort?.direction === 'asc' ? 'desc' : 'asc' })}>ID</th>
              <th onClick={() => setCustomerSort({ key: 'name', direction: customerSort?.direction === 'asc' ? 'desc' : 'asc' })}>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Tier</th>
              <th>Frequency</th>
              <th onClick={() => setCustomerSort({ key: 'joinDate', direction: customerSort?.direction === 'asc' ? 'desc' : 'asc' })}>Join Date</th>
              <th>Active</th>
            </tr>
          </thead>
          <tbody>
            {sortedCustomers.length === 0 ? (
              <tr className="empty-state"><td colSpan={8}>No customers match the criteria.</td></tr>
            ) : (
              sortedCustomers.map((c) => (
                <tr key={c.id} className="table-row">
                  <td className="table-cell">{c.id}</td>
                  <td className="table-cell">{c.name}</td>
                  <td className="table-cell">{c.email}</td>
                  <td className="table-cell">{c.phone}</td>
                  <td className="table-cell">{c.subscriptionTier}</td>
                  <td className="table-cell">{c.frequency}</td>
                  <td className="table-cell">{new Date(c.joinDate).toLocaleDateString()}</td>
                  <td className="table-cell">{c.active ? 'Yes' : 'No'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}