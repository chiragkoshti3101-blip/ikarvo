import { promises as fs } from 'fs';
import path from 'path';

export type OrderStatus = 'pending' | 'roasting' | 'packed' | 'shipped' | 'delivered';

export interface OrderItem {
  productName: string;
  quantity: number;
  pricePerBag: number;
}

export interface Order {
  id: string;
  customerId: string;
  createdAt: string;
  deliveryDate: string;
  status: OrderStatus;
  items: OrderItem[];
  total: number;
  batchNumber: string;
  roastLevel: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  subscriptionTier: string;
  frequency: string;
  joinDate: string;
  active: boolean;
}

const dataDir = path.join(process.cwd(), 'data');
const ordersFile = path.join(dataDir, 'orders.json');
const customersFile = path.join(dataDir, 'customers.json');

function dateOffset(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

function isoOffset(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString();
}

function buildSeedCustomers(): Customer[] {
  return [
    {
      id: 'c-001',
      name: 'Maya Chen',
      email: 'maya.chen@example.com',
      phone: '(415) 555-0134',
      address: '842 Valencia St, San Francisco, CA 94110',
      subscriptionTier: 'Single Origin',
      frequency: 'Weekly',
      joinDate: '2025-01-14',
      active: true,
    },
    {
      id: 'c-002',
      name: 'James Okafor',
      email: 'james.okafor@example.com',
      phone: '(510) 555-0187',
      address: '2211 Broadway, Oakland, CA 94612',
      subscriptionTier: 'House Blend',
      frequency: 'Biweekly',
      joinDate: '2025-02-03',
      active: true,
    },
    {
      id: 'c-003',
      name: 'Priya Sharma',
      email: 'priya.sharma@example.com',
      phone: '(510) 555-0241',
      address: '1901 Shattuck Ave, Berkeley, CA 94704',
      subscriptionTier: 'Reserve',
      frequency: 'Monthly',
      joinDate: '2024-11-20',
      active: true,
    },
    {
      id: 'c-004',
      name: 'Daniel Reyes',
      email: 'daniel.reyes@example.com',
      phone: '(408) 555-0169',
      address: '77 S 1st St, San Jose, CA 95113',
      subscriptionTier: 'Single Origin',
      frequency: 'Weekly',
      joinDate: '2025-03-08',
      active: true,
    },
    {
      id: 'c-005',
      name: 'Emily Watson',
      email: 'emily.watson@example.com',
      phone: '(650) 555-0122',
      address: '530 Bryant St, Palo Alto, CA 94301',
      subscriptionTier: 'House Blend',
      frequency: 'Biweekly',
      joinDate: '2025-04-17',
      active: true,
    },
    {
      id: 'c-006',
      name: 'Tomás Herrera',
      email: 'tomas.herrera@example.com',
      phone: '(916) 555-0195',
      address: '1028 K St, Sacramento, CA 95814',
      subscriptionTier: 'Single Origin',
      frequency: 'Monthly',
      joinDate: '2025-05-02',
      active: true,
    },
    {
      id: 'c-007',
      name: 'Grace Kim',
      email: 'grace.kim@example.com',
      phone: '(415) 555-0218',
      address: '1550 Fillmore St, San Francisco, CA 94115',
      subscriptionTier: 'Reserve',
      frequency: 'Weekly',
      joinDate: '2024-12-05',
      active: true,
    },
  ];
}

function buildSeedOrders(): Order[] {
  return [
    {
      id: 'o-1001',
      customerId: 'c-001',
      createdAt: isoOffset(-2),
      deliveryDate: dateOffset(2),
      status: 'roasting',
      items: [{ productName: 'Oak Single Origin Ethiopia', quantity: 2, pricePerBag: 22 }],
      total: 44,
      batchNumber: 'B-2417',
      roastLevel: 'Light',
    },
    {
      id: 'o-1002',
      customerId: 'c-002',
      createdAt: isoOffset(-1),
      deliveryDate: dateOffset(1),
      status: 'packed',
      items: [{ productName: 'Ember House Blend', quantity: 1, pricePerBag: 18 }],
      total: 18,
      batchNumber: 'B-2416',
      roastLevel: 'Medium',
    },
    {
      id: 'o-1003',
      customerId: 'c-003',
      createdAt: isoOffset(0),
      deliveryDate: dateOffset(4),
      status: 'pending',
      items: [{ productName: 'Reserve Colombia Geisha', quantity: 1, pricePerBag: 32 }],
      total: 32,
      batchNumber: 'B-2418',
      roastLevel: 'Light',
    },
    {
      id: 'o-1004',
      customerId: 'c-004',
      createdAt: isoOffset(-3),
      deliveryDate: dateOffset(0),
      status: 'shipped',
      items: [{ productName: 'Midnight Roast', quantity: 3, pricePerBag: 19 }],
      total: 57,
      batchNumber: 'B-2415',
      roastLevel: 'Dark',
    },
    {
      id: 'o-1005',
      customerId: 'c-005',
      createdAt: isoOffset(-5),
      deliveryDate: dateOffset(-2),
      status: 'delivered',
      items: [{ productName: 'Ember House Blend', quantity: 2, pricePerBag: 18 }],
      total: 36,
      batchNumber: 'B-2414',
      roastLevel: 'Medium',
    },
    {
      id: 'o-1006',
      customerId: 'c-006',
      createdAt: isoOffset(0),
      deliveryDate: dateOffset(5),
      status: 'pending',
      items: [{ productName: 'Oak Single Origin Kenya', quantity: 1, pricePerBag: 21 }],
      total: 21,
      batchNumber: 'B-2418',
      roastLevel: 'Light',
    },
    {
      id: 'o-1007',
      customerId: 'c-007',
      createdAt: isoOffset(-1),
      deliveryDate: dateOffset(3),
      status: 'roasting',
      items: [{ productName: 'Reserve Guatemala', quantity: 2, pricePerBag: 28 }],
      total: 56,
      batchNumber: 'B-2417',
      roastLevel: 'Medium',
    },
    {
      id: 'o-1008',
      customerId: 'c-001',
      createdAt: isoOffset(-7),
      deliveryDate: dateOffset(-4),
      status: 'delivered',
      items: [{ productName: 'Midnight Roast', quantity: 1, pricePerBag: 19 }],
      total: 19,
      batchNumber: 'B-2413',
      roastLevel: 'Dark',
    },
  ];
}

async function ensureDataDir(): Promise<void> {
  await fs.mkdir(dataDir, { recursive: true });
}

async function readJsonFile<T>(filePath: string, fallback: T): Promise<T>