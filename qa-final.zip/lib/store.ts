import fs from 'fs';
import path from 'path';

export type OrderStatus = 'scheduled' | 'roasting' | 'packed' | 'shipped' | 'delivered';

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  status: OrderStatus;
  amount: number;
  bags: number;
  batch: string;
  roastLevel: string;
  date: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  subscription: string;
  roastPreference: string;
  since: string;
  lastOrder: string;
  totalOrders: number;
  lifetimeValue: number;
}

export interface StoreData {
  orders: Order[];
  customers: Customer[];
}

const DATA_DIR = process.env.VERCEL ? '/tmp/data' : path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'data.json');

function dayOffset(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().split('T')[0];
}

function seedData(): StoreData {
  const customers: Customer[] = [
    { id: 'c1', name: 'Maya Chen', email: 'maya.chen@emberandoak.com', subscription: 'Whole Bean', roastPreference: 'Light', since: '2024-01-12', lastOrder: dayOffset(-1), totalOrders: 28, lifetimeValue: 588 },
    { id: 'c2', name: 'James Okafor', email: 'j.okafor@emberandoak.com', subscription: 'Ground', roastPreference: 'Medium', since: '2024-03-05', lastOrder: dayOffset(-2), totalOrders: 22, lifetimeValue: 462 },
    { id: 'c3', name: 'Sarah Lindqvist', email: 'sarah.l@emberandoak.com', subscription: 'Whole Bean', roastPreference: 'Dark', since: '2024-06-18', lastOrder: dayOffset(-3), totalOrders: 15, lifetimeValue: 345 },
    { id: 'c4', name: 'David Park', email: 'd.park@emberandoak.com', subscription: 'Espresso', roastPreference: 'Medium-Dark', since: '2024-09-02', lastOrder: dayOffset(-1), totalOrders: 12, lifetimeValue: 288 },
    { id: 'c5', name: 'Elena Rodriguez', email: 'elena.r@emberandoak.com', subscription: 'Decaf', roastPreference: 'Medium', since: '2024-11-20', lastOrder: dayOffset(-4), totalOrders: 9, lifetimeValue: 207 },
    { id: 'c6', name: 'Tom Whitfield', email: 'tom.w@emberandoak.com', subscription: 'Whole Bean', roastPreference: 'Light', since: '2025-02-14', lastOrder: dayOffset(-2), totalOrders: 6, lifetimeValue: 126 },
    { id: 'c7', name: 'Priya Sharma', email: 'priya.s@emberandoak.com', subscription: 'Ground', roastPreference: 'Medium', since: '2025-04-08', lastOrder: dayOffset(-1), totalOrders: 4, lifetimeValue: 84 },
  ];

  const orders: Order[] = [
    { id: 'o1', customerId: 'c1', customerName: 'Maya Chen', status: 'roasting', amount: 42, bags: 2, batch: 'RB-2417', roastLevel: 'Light', date: dayOffset(-1) },
    { id: 'o2', customerId: 'c2', customerName: 'James Okafor', status: 'packed', amount: 21, bags: 1, batch: 'RB-2416', roastLevel: 'Medium', date: dayOffset(-2) },
    { id: 'o3', customerId: 'c3', customerName: 'Sarah Lindqvist', status: 'shipped', amount: 63, bags: 3, batch: 'RB-2415', roastLevel: 'Dark', date: dayOffset(-3) },
    { id: 'o4', customerId: 'c4', customerName: 'David Park', status: 'scheduled', amount: 44, bags: 2, batch: 'RB-2418', roastLevel: 'Medium-Dark', date: dayOffset(0) },
    { id: 'o5', customerId: 'c5', customerName: 'Elena Rodriguez', status: 'delivered', amount: 23, bags: 1, batch: 'RB-2414', roastLevel: 'Medium', date: dayOffset(-4) },
    { id: 'o6', customerId: 'c6', customerName: 'Tom Whitfield', status: 'roasting', amount: 42, bags: 2, batch: 'RB-2417', roastLevel: 'Light', date: dayOffset(-1) },
    { id: 'o7', customerId: 'c7', customerName: 'Priya Sharma', status: 'packed', amount: 21, bags: 1, batch: 'RB-2416', roastLevel: 'Medium', date: dayOffset(-2) },
    { id: 'o8', customerId: 'c1', customerName: 'Maya Chen', status: 'scheduled', amount: 21, bags: 1, batch: 'RB-2419', roastLevel: 'Light', date: dayOffset(1) },
  ];

  return { orders, customers };
}

export async function loadStore(): Promise<StoreData> {
  try {
    const raw = await fs.promises.readFile(DATA_FILE, 'utf-8');
    return JSON.parse(raw) as StoreData;
  } catch {
    const seeded = seedData();
    await saveStore(seeded);
    return seeded;
  }
}

export async function saveStore(data: StoreData): Promise<void> {
  await fs.promises.mkdir(DATA_DIR, { recursive: true });
  await fs.promises.writeFile(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

export async function getOrders(): Promise<Order[]> {
  const store = await loadStore();
  return store.orders;
}

export async function getCustomers(): Promise<Customer[]> {
  const store = await loadStore();
  return store.customers;
}

export async function addOrder(order: Order): Promise<Order> {
  const store = await loadStore();
  store.orders.push(order);
  await saveStore(store);
  return order;
}

export async function updateOrder(id: string, updates: Partial<Order>): Promise<Order | null> {
  const store = await loadStore();
  const index = store.orders.findIndex(o => o.id === id);
  if (index === -1) return null;
  store.orders[index] = { ...store.orders[index], ...updates };
  await saveStore(store);
  return store.orders[index];
}

export async function addCustomer(customer: Customer): Promise<Customer> {
  const store = await loadStore();
  store.customers.push(customer);
  await saveStore(store);
  return customer;
}

export async function updateCustomer(id: string, updates: Partial<Customer>): Promise<Customer | null> {
  const store = await loadStore();
  const index = store.customers.findIndex(c => c.id === id);
  if (index === -1) return null;
  store.customers[index] = { ...store.customers[index], ...updates };
  await saveStore(store);
  return store.customers[index];
}