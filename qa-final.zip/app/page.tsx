'use client';
import { useEffect, useState, useMemo } from 'react';
import DataTable from './components/datatable';
import { Order, Customer, OrderStatus } from '../lib/store';
import { stringify } from 'csv-stringify/sync';

type View = 'orders' | 'customers';

interface KPI {
  label: string;
  value: string | number;
}

export default function Dashboard() {
  const [view, setView] = useState<View>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [subscriptionFilter, setSubscriptionFilter] = useState<string>('all');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/data?type=${view}`);
      if (!res.ok) throw new Error('Network response was not ok');
      const data = await res.json();
      if (view === 'orders') setOrders(data);
      else setCustomers(data);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [view]);

  const filteredRows = useMemo(() => {
    const rows = view === 'orders' ? orders : customers;
    return rows.filter(row => {
      const searchable = Object.values(row).join(' ').toLowerCase();
      if (search && !searchable.includes(search.toLowerCase())) return false;
      if (view === 'orders') {
        const o = row as Order;
        if (statusFilter !== 'all' && o.status !== statusFilter) return false;
        if (dateFrom && o.date < dateFrom) return false;
        if (dateTo && o.date > dateTo) return false;
      } else {
        const c = row as Customer;
        if (subscriptionFilter !== 'all' && c.subscription !== subscriptionFilter) return false;
      }
      return true;
    });
  }, [view, orders, customers, search, statusFilter, subscriptionFilter, dateFrom, dateTo]);

  const kpis: KPI[] = useMemo(() => {
    if (view === 'orders') {
      const totalRevenue = orders.reduce((sum, o) => sum + o.amount, 0);
      const openOrders = orders.filter(o => o.status !== 'delivered').length;
      const totalBags = orders.reduce((sum, o) => sum + o.bags, 0);
      const batches = new Set(orders.map(o => o.batch)).size;
      return [
        { label: 'Revenue (USD)', value: `$${totalRevenue}` },
        { label: 'Open Orders', value: openOrders },
        { label: 'Bags to Ship', value: totalBags },
        { label: 'Batches', value: batches },
      ];
    } else {
      const totalCustomers = customers.length;
      const totalLifetime = customers.reduce((sum, c) => sum + c.lifetimeValue, 0);
      const avgOrders = (customers.reduce((sum, c) => sum + c.totalOrders, 0) / totalCustomers).toFixed(1);
      return [
        { label: 'Customers', value: totalCustomers },
        { label: 'Lifetime Value (USD)', value: `$${totalLifetime}` },
        { label: 'Avg Orders per Customer', value: avgOrders },
      ];
    }
  }, [view, orders, customers]);

  const handleStatusChange = async (id: string, newStatus: OrderStatus) => {
    try {
      const res = await fetch('/api/data?type=orders', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, updates: { status: newStatus } }),
      });
      if (!res.ok) throw new Error('Failed to update');
      const updated = await res.json();
      setOrders(prev => prev.map(o => (o.id === id ? updated : o)));
    } catch (e) {}
  };

  const exportCSV = () => {
    const rows = filteredRows;
    const columns = view === 'orders'
      ? ['id', 'customerName', 'status', 'amount', 'bags', 'batch', 'roastLevel', 'date']
      : ['id', 'name', 'email', 'subscription', 'roastPreference', 'since', 'lastOrder', 'totalOrders', 'lifetimeValue'];
    const data = rows.map(r => columns.map(c => (r as any)[c]));
    const csv = stringify([columns, ...data]);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${view}_export.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const orderColumns = [
    { key: 'date', label: 'Date', sortable: true },
    { key: 'customerName', label: 'Customer', sortable: true },
    { key: 'batch', label: 'Batch', sortable: true },
    { key: 'roastLevel', label: 'Roast', sortable: true },
    { key: 'bags', label: 'Bags', sortable: true },
    { key: 'amount', label: 'Amount ($)', sortable: true },
    { key: 'status', label: 'Status', sortable: true },
  ];

  const customerColumns = [
    { key: 'name', label: 'Name', sortable: true },
    { key: 'email', label: 'Email', sortable: true },
    { key: 'subscription', label: 'Subscription', sortable: true },
    { key: 'roastPreference', label: 'Roast Pref.', sortable: true },
    { key: 'since', label: 'Since', sortable: true },
    { key: 'totalOrders', label: 'Orders', sortable: true },
    { key: 'lifetimeValue', label: 'Lifetime ($)', sortable: true },
  ];

  const renderRow = (row: any) => {
    if (view === 'orders') {
      const o = row as Order;
      return (
        <>
          <td>{o.date}</td>
          <td>{o.customerName}</td>
          <td>{o.batch}</td>
          <td>{o.roastLevel}</td>
          <td>{o.bags}</td>
          <td>{o.amount}</td>
          <td>
            <select
              value={o.status}
              onChange={e => handleStatusChange(o.id, e.target.value as OrderStatus)}
            >
              <option value="scheduled">scheduled</option>
              <option value="roasting">roasting</option>
              <option value="packed">packed</option>
              <option value="shipped">shipped</option>
              <option value="delivered">delivered</option>
            </select>
          </td>
        </>
      );
    } else {
      const c = row as Customer;
      return (
        <>
          <td>{c.name}</td>
          <td>{c.email}</td>
          <td>{c.subscription}</td>
          <td>{c.roastPreference}</td>
          <td>{c.since}</td>
          <td>{c.totalOrders}</td>
          <td>{c.lifetimeValue}</td>
        </>
      );
    }
  };

  return (
    <div className="dashboard">
      <header className="header">
        <h1>Ember &amp; Oak – Order Desk</h1>
        <p className="subtitle">Real‑time view of weekly subscription orders and customers.</p>
      </header>

      <nav className="tabs">
        <button
          className={view === 'orders' ? 'active' : ''}
          onClick={() => setView('orders')}
        >
          Orders
        </button>
        <button
          className={view === 'customers' ? 'active' : ''}
          onClick={() => setView('customers')}
        >
          Customers
        </button>
      </nav>

      <section className="kpi-row">
        {kpis.map(k => (
          <div key={k.label} className="kpi">
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
          </div>
        ))}
      </section>

      <section className="controls">
        <input
          type="text"
          placeholder="Search…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="search"
        />
        {view === 'orders' && (
          <>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value as OrderStatus | 'all')}
              className="filter"
            >
              <option value="all">All statuses</option>
              <option value="scheduled">scheduled</option>
              <option value="roasting">roasting</option>
              <option value="packed">packed</option>
              <option value="shipped">shipped</option>
              <option value="delivered">delivered</option>
            </select>
            <input
              type="date"
              value={dateFrom}
              onChange={e => setDateFrom(e.target.value)}
              className="date-filter"
            />
            <input
              type="date"
              value={dateTo}
              onChange={e => setDateTo(e.target.value)}
              className="date-filter"
            />
          </>
        )}
        {view === 'customers' && (
          <select
            value={subscriptionFilter}
            onChange={e => setSubscriptionFilter(e.target.value)}
            className="filter"
          >
            <option value="all">All subscriptions</option>
            <option value="Whole Bean">Whole Bean</option>
            <option value="Ground">Ground</option>
            <option value="Espresso">Espresso</option>
            <option value="Decaf">Decaf</option>
          </select>
        )}
        <button onClick={exportCSV} className="export">
          Export CSV
        </button>
      </section>

      {loading && <p className="status">Loading…</p>}
      {error && <p className="status error">Error: {error}</p>}
      {!loading && !error && filteredRows.length === 0 && (
        <p className="status empty">No records match your criteria.</p>
      )}
      {!loading && !error && filteredRows.length > 0 && (
        <DataTable
          columns={view === 'orders' ? orderColumns : customerColumns}
          rows={filteredRows}
          loading={false}
          emptyMessage="No data"
          onRowClick={() => {}}
        >
          {renderRow}
        </DataTable>
      )}

      <footer className="footer">
        <p>Sample data loaded on first run.</p>
      </footer>
    </div>
  );
}