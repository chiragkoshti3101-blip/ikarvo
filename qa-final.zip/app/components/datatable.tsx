'use client';

interface Column {
  key: string;
  label: string;
  sortable?: boolean;
}

interface DataTableProps {
  columns: Column[];
  rows: any[];
  onSort?: (key: string) => void;
  onRowClick?: (row: any) => void;
  loading: boolean;
  emptyMessage: string;
  sortKey?: string;
  sortDirection?: 'asc' | 'desc';
}

export default function DataTable({
  columns,
  rows,
  onSort,
  onRowClick,
  loading,
  emptyMessage,
  sortKey,
  sortDirection,
}: DataTableProps) {
  if (loading) {
    return (
      <div className="data-table-loading" role="status" aria-live="polite">
        <span className="spinner" aria-hidden="true" />
        <span>Loading records…</span>
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div className="data-table-empty" role="status">
        <p>{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="data-table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map(col => {
              const isSorted = sortKey === col.key;
              const ariaSort = isSorted
                ? sortDirection === 'asc'
                  ? 'ascending'
                  : 'descending'
                : undefined;
              return (
                <th key={col.key} scope="col" aria-sort={ariaSort}>
                  {col.sortable && onSort ? (
                    <button
                      type="button"
                      className="sort-button"
                      onClick={() => onSort(col.key)}
                      aria-label={`Sort by ${col.label}`}
                    >
                      {col.label}
                      <span className="sort-indicator" aria-hidden="true">
                        {isSorted ? (sortDirection === 'asc' ? '↑' : '↓') : ''}
                      </span>
                    </button>
                  ) : (
                    col.label
                  )}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr
              key={row.id ?? i}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              className={onRowClick ? 'clickable' : undefined}
              tabIndex={onRowClick ? 0 : undefined}
              onKeyDown={
                onRowClick
                  ? e => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        onRowClick(row);
                      }
                    }
                  : undefined
              }
            >
              {columns.map(col => (
                <td key={col.key}>{row[col.key]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}