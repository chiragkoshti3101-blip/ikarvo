import React from 'react';
import './globals.css';

export const metadata = {
  title: 'Ember & Oak – Order Desk',
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <title>{metadata.title}</title>
      </head>
      <body className="shell">
        <aside className="sidebar">
          <nav>
            <a href="/" className="nav-link">
              Dashboard
            </a>
            <a href="/orders" className="nav-link">
              Orders
            </a>
            <a href="/customers" className="nav-link">
              Customers
            </a>
          </nav>
        </aside>
        <main className="main-content">{children}</main>
      </body>
    </html>
  );
}