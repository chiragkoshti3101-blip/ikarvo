import { NextRequest, NextResponse } from 'next/server';
import { getOrders, getCustomers, addOrder, updateOrder, addCustomer, updateCustomer, loadStore, saveStore } from '../../../lib/store';
import type { Order, Customer, OrderStatus } from '../../../lib/store';

const ORDER_STATUSES: OrderStatus[] = ['scheduled', 'roasting', 'packed', 'shipped', 'delivered'];

function isValidDate(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value));
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function validateOrder(input: unknown): { ok: true; order: Order } | { ok: false; error: string } {
  const o = input as Record<string, unknown>;
  if (!o || typeof o !== 'object') return { ok: false, error: 'Invalid order payload.' };
  if (typeof o.id !== 'string' || !o.id.trim()) return { ok: false, error: 'Order id is required.' };
  if (typeof o.customerId !== 'string' || !o.customerId.trim()) return { ok: false, error: 'customerId is required.' };
  if (typeof o.customerName !== 'string' || !o.customerName.trim()) return { ok: false, error: 'customerName is required.' };
  if (typeof o.status !== 'string' || !ORDER_STATUSES.includes(o.status as OrderStatus)) return { ok: false, error: 'status must be one of scheduled, roasting, packed, shipped, delivered.' };
  if (typeof o.amount !== 'number' || !Number.isFinite(o.amount) || o.amount <= 0) return { ok: false, error: 'amount must be a positive number.' };
  if (typeof o.bags !== 'number' || !Number.isInteger(o.bags) || o.bags <= 0) return { ok: false, error: 'bags must be a positive integer.' };
  if (typeof o.batch !== 'string' || !o.batch.trim()) return { ok: false, error: 'batch is required.' };
  if (typeof o.roastLevel !== 'string' || !o.roastLevel.trim()) return { ok: false, error: 'roastLevel is required.' };
  if (typeof o.date !== 'string' || !isValidDate(o.date)) return { ok: false, error: 'date must be YYYY-MM-DD.' };
  return { ok: true, order: o as unknown as Order };
}

function validateCustomer(input: unknown): { ok: true; customer: Customer } | { ok: false; error: string } {
  const c = input as Record<string, unknown>;
  if (!c || typeof c !== 'object') return { ok: false, error: 'Invalid customer payload.' };
  if (typeof c.id !== 'string' || !c.id.trim()) return { ok: false, error: 'Customer id is required.' };
  if (typeof c.name !== 'string' || !c.name.trim()) return { ok: false, error: 'name is required.' };
  if (typeof c.email !== 'string' || !isValidEmail(c.email)) return { ok: false, error: 'A valid email is required.' };
  if (typeof c.subscription !== 'string' || !c.subscription.trim()) return { ok: false, error: 'subscription is required.' };
  if (typeof c.roastPreference !== 'string' || !c.roastPreference.trim()) return { ok: false, error: 'roastPreference is required.' };
  if (typeof c.since !== 'string' || !isValidDate(c.since)) return { ok: false, error: 'since must be YYYY-MM-DD.' };
  if (typeof c.lastOrder !== 'string' || !isValidDate(c.lastOrder)) return { ok: false, error: 'lastOrder must be YYYY-MM-DD.' };
  if (typeof c.totalOrders !== 'number' || !Number.isInteger(c.totalOrders) || c.totalOrders < 0) return { ok: false, error: 'totalOrders must be a non-negative integer.' };
  if (typeof c.lifetimeValue !== 'number' || !Number.isFinite(c.lifetimeValue) || c.lifetimeValue < 0) return { ok: false, error: 'lifetimeValue must be a non-negative number.' };
  return { ok: true, customer: c as unknown as Customer };
}

function validateOrderUpdate(input: unknown): { ok: true; updates: Partial<Order> } | { ok: false; error: string } {
  const o = input as Record<string, unknown>;
  if (!o || typeof o !== 'object') return { ok: false, error: 'Invalid update payload.' };
  const updates: Partial<Order> = {};
  if ('status' in o) {
    if (typeof o.status !== 'string' || !ORDER_STATUSES.includes(o.status as OrderStatus)) return { ok: false, error: 'status must be one of scheduled, roasting, packed, shipped, delivered.' };
    updates.status = o.status as OrderStatus;
  }
  if ('amount' in o) {
    if (typeof o.amount !== 'number' || !Number.isFinite(o.amount) || o.amount <= 0) return { ok: false, error: 'amount must be a positive number.' };
    updates.amount = o.amount;
  }
  if ('bags' in o) {
    if (typeof o.bags !== 'number' || !Number.isInteger(o.bags) || o.bags <= 0) return { ok: false, error: 'bags must be a positive integer.' };
    updates.bags = o.bags;
  }
  if ('batch' in o) {
    if (typeof o.batch !== 'string' || !o.batch.trim()) return { ok: false, error: 'batch is required.' };
    updates.batch = o.batch;
  }
  if ('roastLevel' in o) {
    if (typeof o.roastLevel !== 'string' || !o.roastLevel.trim()) return { ok: false, error: 'roastLevel is required.' };
    updates.roastLevel = o.roastLevel;
  }
  if ('date' in o) {
    if (typeof o.date !== 'string' || !isValidDate(o.date)) return { ok: false, error: 'date must be YYYY-MM-DD.' };
    updates.date = o.date;
  }
  if ('customerName' in o) {
    if (typeof o.customerName !== 'string' || !o.customerName.trim()) return { ok: false, error: 'customerName is required.' };
    updates.customerName = o.customerName;
  }
  if ('customerId' in o) {
    if (typeof o.customerId !== 'string' || !o.customerId.trim()) return { ok: false, error: 'customerId is required.' };
    updates.customerId = o.customerId;
  }
  return { ok: true, updates };
}

function validateCustomerUpdate(input: unknown): { ok: true; updates: Partial<Customer> } | { ok: false; error: string } {
  const c = input as Record<string, unknown>;
  if (!c || typeof c !== 'object') return { ok: false, error: 'Invalid update payload.' };
  const updates: Partial<Customer> = {};
  if ('name' in c) {
    if (typeof c.name !== 'string' || !c.name.trim()) return { ok: false, error: 'name is required.' };
    updates.name = c.name;
  }
  if ('email' in c) {
    if (typeof c.email !== 'string' || !isValidEmail(c.email)) return { ok: false, error: 'A valid email is required.' };
    updates.email = c.email;
  }
  if ('subscription' in c) {
    if (typeof c.subscription !== 'string' || !c.subscription.trim()) return { ok: false, error: 'subscription is required.' };
    updates.subscription = c.subscription;
  }
  if ('roastPreference' in c) {
    if (typeof c.roastPreference !== 'string' || !c.roastPreference.trim()) return { ok: false, error: 'roastPreference is required.' };
    updates.roastPreference = c.roastPreference;
  }
  if ('since' in c) {
    if (typeof c.since !== 'string' || !isValidDate(c.since)) return { ok: false, error: 'since must be YYYY-MM-DD.' };
    updates.since = c.since;
  }
  if ('lastOrder' in c) {
    if (typeof c.lastOrder !== 'string' || !isValidDate(c.lastOrder)) return { ok: false, error: 'lastOrder must be YYYY-MM-DD.' };
    updates.lastOrder = c.lastOrder;
  }
  if ('totalOrders' in c) {
    if (typeof c.totalOrders !== 'number' || !Number.isInteger(c.totalOrders) || c.totalOrders < 0) return { ok: false, error: 'totalOrders must be a non-negative integer.' };
    updates.totalOrders = c.totalOrders;
  }
  if ('lifetimeValue' in c) {
    if (typeof c.lifetimeValue !== 'number' || !Number.isFinite(c.lifetimeValue) || c.lifetimeValue < 0) return { ok: false, error: 'lifetimeValue must be a non-negative number.' };
    updates.lifetimeValue = c.lifetimeValue;
  }
  return { ok: true, updates };
}

async function deleteOrder(id: string): Promise<boolean> {
  const store = await loadStore();
  const before = store.orders.length;
  store.orders = store.orders.filter(o => o.id !== id);
  if (store.orders.length === before) return false;
  await saveStore(store);
  return true;
}

async function deleteCustomer(id: string): Promise<boolean> {
  const store = await loadStore();
  const before = store.customers.length;
  store.customers = store.customers.filter(c => c.id !== id);
  if (store.customers.length === before) return false;
  await saveStore(store);
  return true;
}

export async function GET(request: NextRequest) {
  const type = request.nextUrl.searchParams.get('type');
  if (type === 'orders') {
    const orders = await getOrders();
    return NextResponse.json({ orders });
  }
  if (type === 'customers') {
    const customers = await getCustomers();
    return NextResponse.json({ customers });
  }
  return NextResponse.json({ error: 'type must be "orders" or "customers".' }, { status: 400 });
}

export async function POST(request: NextRequest) {
  const type = request.nextUrl.searchParams.get('type');
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Request body must be valid JSON.' }, { status: 400 });
  }
  if (type === 'orders') {
    const result = validateOrder(body);
    if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
    const orders = await getOrders();
    if (orders.some(o => o.id === result.order.id)) {
      return NextResponse.json({ error: `An order with id ${result.order.id} already exists.` }, { status: 409 });
    }
    const order = await addOrder(result.order);
    return NextResponse.json({ order }, { status: 201 });
  }
  if (type === 'customers') {
    const result = validateCustomer(body);
    if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
    const customers = await getCustomers();
    if (customers.some(c => c.id === result.customer.id)) {
      return NextResponse.json({ error: `A customer with id ${result.customer.id} already exists.` }, { status: 409 });
    }
    const customer = await addCustomer(result.customer);
    return NextResponse.json({ customer }, { status: 201 });
  }
  return NextResponse.json({ error: 'type must be "orders" or "customers".' }, { status: 400 });
}

export async function PUT(request: NextRequest) {
  const type = request.nextUrl.searchParams.get('type');
  const id = request.nextUrl.searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'id query parameter is required.' }, { status: 400 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Request body must be valid JSON.' }, { status: 400 });
  }
  if (type === 'orders') {
    const result = validateOrderUpdate(body);
    if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
    const order = await updateOrder(id, result.updates);
    if (!order) return NextResponse.json({ error: 'Order not found.' }, { status: 404 });
    return NextResponse.json({ order });
  }
  if (type === 'customers') {
    const result = validateCustomerUpdate(body);
    if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
    const customer = await updateCustomer(id, result.updates);
    if (!customer) return NextResponse.json({ error: 'Customer not found.' }, { status: 404 });
    return NextResponse.json({ customer });
  }
  return NextResponse.json({ error: 'type must be "orders" or "customers".' }, { status: 400 });
}

export async function DELETE(request: NextRequest) {
  const type = request.nextUrl.searchParams.get('type');
  const id = request.nextUrl.searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'id query parameter is required.' }, { status: 400 });
  if (type === 'orders') {
    const deleted = await deleteOrder(id);
    if (!deleted) return NextResponse.json({ error: 'Order not found.' }, { status: 404 });
    return NextResponse.json({ ok: true });
  }
  if (type === 'customers') {
    const deleted = await deleteCustomer(id);
    if (!deleted) return NextResponse.json({ error: 'Customer not found.' }, { status: 404 });
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: 'type must be "orders" or "customers".' }, { status: 400 });
}