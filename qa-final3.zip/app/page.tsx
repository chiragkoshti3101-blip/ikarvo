'use client';

import { useEffect, useState, ChangeEvent, MouseEvent } from 'react';
import { Order, Customer } from '../lib/store';
import { format } from 'date-fns';

type Tab = 'orders' | 'customers';
type SortDirection = 'asc' | 'desc';

export default function DashboardPage() {
  const [tab, setTab] = useState<Tab>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState<string>('');
  const [statusFilters, setStatusFilters] = useState<Set<Order['status']>>(
    new Set()
  );
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [sortKey, setSortKey] = useState<keyof Order | keyof Customer>('date');
  const [sortDir, setSortDir] = useState<SortDirection>('asc');

  // Fetch data
  useEffect(() => {
    async function load() {
      setLoading(true);
      setError(null);
      try {
        const [ordersRes, customersRes] = await Promise.all([
          fetch('/api/data?type=orders'),
          fetch('/api/data?type=customers'),
        ]);
        if (!ordersRes.ok || !customersRes.ok) {
          throw new Error('Failed to load data');
        }
        const ordersData: Order[] = await ordersRes.json();
        const customersData: Customer[] = await customersRes.json();
        setOrders(ordersData);
        setCustomers(customersData);
      } catch (e: any) {
        setError(e.message ?? 'Unknown error');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  // Helpers
  const getCustomerName = (id: string) => {
    const c = customers.find(c => c.id === id);
    return c ? c.name : 'Unknown';
  };

  const handleStatusChange = async (orderId: string, newStatus: Order['status']) => {
    try {
      const res = await fetch('/api/data?type=orders', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: orderId, updates: { status: newStatus } }),
      });
      if (!res.ok) throw new Error('Update failed');
      const updated: Order = await res.json();
      setOrders(prev => prev.map(o => (o.id === updated.id ? updated : o)));
    } catch (e) {
      console.error(e);
    }
  };

  const toggleStatusFilter = (status: Order['status']) => {
    setStatusFilters(prev => {
      const next = new Set(prev);
      if (next.has(status)) next.delete(status);
      else next.add(status);
      return next;
    });
  };

  const handleSort = (key: keyof Order | keyof Customer) => {
    if (sortKey === key) {
      setSortDir(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  const filteredOrders = orders
    .filter(o => {
      if (search) {
        const custName = getCustomerName(o.customerId).toLowerCase();
        if (!custName.includes(search.toLowerCase())) return false;
      }
      if (statusFilters.size && !statusFilters.has(o.status)) return false;
      if (dateFrom && new Date(o.date) < new Date(dateFrom)) return false;
      if (dateTo && new Date(o.date) > new Date(dateTo)) return false;
      return true;
    })
    .sort((a, b) => {
      const aVal = (a as any)[sortKey];
      const bVal = (b as any)[sortKey];
      if (aVal < bVal) return sortDir === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });

  const filteredCustomers = customers
    .filter(c => {
      if (!search) return true;
      const term = search.toLowerCase();
      return (
        c.name.toLowerCase().includes(term) ||
        c.email.toLowerCase().includes(term) ||
        c.address.toLowerCase().includes(term)
      );
    })
    .sort((a, b) => {
      const aVal = (a as any)[sortKey];
      const bVal = (b as any)[sortKey];
      if (aVal < bVal) return sortDir === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });

  // KPI calculations (orders view only)
  const totalRevenue = orders.reduce(
    (sum, o) => sum + o.bags * o.unitPrice,
    0
  );
  const pendingCount = orders.filter(o => o.status === 'Pending').length;
  const totalBags = orders.reduce((sum, o) => sum + o.bags, 0);
  const distinctBatches = new Set(orders.map(o => o.date.slice(0, 10))).size;

  // CSV export
  const exportCSV = () => {
    const rows = tab === 'orders' ? filteredOrders : filteredCustomers;
    const headers =
      tab === 'orders'
        ? [
            'Date',
            'Customer',
            'Bags',
            'Unit Price',
            'Total',
            'Status',
          ]
        : ['Name', 'Email', 'Subscription', 'Address'];
    const csvContent = [
      headers.join(','),
      ...rows.map(r => {
        if (tab === 'orders') {
          const o = r as Order;
          const total = (o.bags * o.unitPrice).toFixed(2);
          return [
            format(new Date(o.date), 'yyyy-MM-dd'),
            `"${getCustomerName(o.customerId)}"`,
            o.bags,
            o.unitPrice.toFixed(2),
            total,
            o.status,
          ].join(',');
        } else {
          const c = r as Customer;
          return [
            `"${c.name}"`,
            `"${c.email}"`,
            c.subscription,
            `"${c.address}"`,
          ].join(',');
        }
      }),
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${tab}-export.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <div className="shell">Loading…</div>;
  if (error) return <div className="shell error">Error: {error}</div>;

  return (
    <div className="shell">
      <header className="header">
        <h1>Ember &amp; Oak – Order Desk</h1>
        <nav className="tabs">
          <button
            className={tab === 'orders' ? 'active' : ''}
            onClick={() => setTab('orders')}
          >
            Orders
          </button>
          <button
            className={tab === 'customers' ? 'active' : ''}
            onClick={() => setTab('customers')}
          >
            Customers
          </button>
        </nav>
      </header>

      {tab === 'orders' && (
        <section className="kpi-row">
          <div className="kpi">
            <label>Total Revenue</label>
            <span>${totalRevenue.toFixed(2)}</span>
          </div>
          <div className="kpi">
            <label>Pending Orders</label>
            <span>{pendingCount}</span>
          </div>
          <div className="kpi">
            <label>Total Bags</label>
            <span>{totalBags}</span>
          </div>
          <div className="kpi">
            <label>Roast Batches</label>
            <span>{distinctBatches}</span>
          </div>
        </section>
      )}

      <section className="controls">
        <input
          type="text"
          placeholder={tab === 'orders' ? 'Search by customer' : 'Search customers'}
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="search"
        />
        {tab === 'orders' && (
          <>
            <div className="status-filters">
              {(['Pending', 'Roasting', 'Shipped', 'Cancelled'] as Order['status'][]).map(
                s => (
                  <button
                    key={s}
                    className={statusFilters.has(s) ? 'active' : ''}
                    onClick={() => toggleStatusFilter(s)}
                  >
                    {s}
                  </button>
                )
              )}
            </div>
            <div className="date-filters">
              <label>
                From
                <input
                  type="date"
                  value={dateFrom}
                  onChange={e => setDateFrom(e.target.value)}
                />
              </label>
              <label>
                To
                <input
                  type="date"
                  value={dateTo}
                  onChange={e => setDateTo(e.target.value)}
                />
              </label>
            </div>
          </>
        )}
        <button onClick={exportCSV} className="export">
          Export CSV
        </button>
      </section>

      {tab === 'orders' && (
        <table className="data-table">
          <thead>
            <tr>
              <th onClick={() => handleSort('date')}>Date</th>
              <th onClick={() => handleSort('customerId')}>Customer</th>
              <th onClick={() => handleSort('bags')}>Bags</th>
              <th onClick={() => handleSort('unitPrice')}>Unit Price</th>
              <th>Total</th>
              <th onClick={() => handleSort('status')}>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.length === 0 ? (
              <tr>
                <td colSpan={7} className="empty">
                  No orders match the current filters.
                </td>
              </tr>
            ) : (
              filteredOrders.map(o => (
                <tr key={o.id}>
                  <td>{format(new Date(o.date), 'yyyy-MM-dd')}</td>
                  <td>{getCustomerName(o.customerId)}</td>
                  <td>{o.bags}</td>
                  <td>${o.unitPrice.toFixed(2)}</td>
                  <td>${(o.bags * o.unitPrice).toFixed(2)}</td>
                  <td>{o.status}</td>
                  <td>
                    <select
                      value={o.status}
                      onChange={e =>
                        handleStatusChange(o.id, e.target.value as Order['status'])
                      }
                    >
                      {(['Pending', 'Roasting', 'Shipped', 'Cancelled'] as Order['status'][]).map(
                        s => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        )
                      )}
                    </select>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}

      {tab === 'customers' && (
        <table className="data-table">
          <thead>
            <tr>
              <th onClick={() => handleSort('name')}>Name</th>
              <th onClick={() => handleSort('email')}>Email</th>
              <th onClick={() => handleSort('subscription')}>Subscription</th>
              <th onClick={() => handleSort('address')}>Address</th>
            </tr>
          </thead>
          <tbody>
            {filteredCustomers.length === 0 ? (
              <tr>
                <td colSpan={4} className="empty">
                  No customers match the search.
                </td>
              </tr>
            ) : (
              filteredCustomers.map(c => (
                <tr key={c.id}>
                  <td>{c.name}</td>
                  <td>{c.email}</td>
                  <td>{c.subscription}</td>
                  <td>{c.address}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}