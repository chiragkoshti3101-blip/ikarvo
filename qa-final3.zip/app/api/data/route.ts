import { NextResponse } from 'next/server';
import {
  getOrders,
  getCustomers,
  addOrder,
  updateOrder,
  addCustomer,
  updateCustomer,
} from '../../../lib/store';

type OrderStatus = 'Pending' | 'Roasting' | 'Shipped' | 'Cancelled';
type Subscription = 'Weekly' | 'Monthly' | 'Quarterly';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');
  if (type !== 'orders' && type !== 'customers') {
    return NextResponse.json({ error: 'type query must be orders or customers' }, { status: 400 });
  }
  if (type === 'orders') {
    const orders = await getOrders();
    return NextResponse.json({ orders });
  }
  const customers = await getCustomers();
  return NextResponse.json({ customers });
}

export async function POST(request: Request) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');
  if (type !== 'orders' && type !== 'customers') {
    return NextResponse.json({ error: 'type query must be orders or customers' }, { status: 400 });
  }
  const body = await request.json();

  if (type === 'orders') {
    if (typeof body.customerId !== 'string' || !body.customerId.trim())
      return NextResponse.json({ error: 'customerId is required' }, { status: 400 });
    if (typeof body.date !== 'string' || !Date.parse(body.date))
      return NextResponse.json({ error: 'valid date is required' }, { status: 400 });
    if (!['Pending', 'Roasting', 'Shipped', 'Cancelled'].includes(body.status))
      return NextResponse.json({ error: 'valid status is required' }, { status: 400 });
    if (typeof body.bags !== 'number' || body.bags < 0)
      return NextResponse.json({ error: 'bags must be a non‑negative number' }, { status: 400 });
    if (typeof body.unitPrice !== 'number' || body.unitPrice < 0)
      return NextResponse.json({ error: 'unitPrice must be a non‑negative number' }, { status: 400 });

    const newOrder = await addOrder({
      customerId: body.customerId,
      date: body.date,
      status: body.status as OrderStatus,
      bags: body.bags,
      unitPrice: body.unitPrice,
    });
    return NextResponse.json({ order: newOrder }, { status: 201 });
  }

  // customers
  if (typeof body.name !== 'string' || !body.name.trim())
    return NextResponse.json({ error: 'name is required' }, { status: 400 });
  if (typeof body.email !== 'string' || !body.email.trim())
    return NextResponse.json({ error: 'email is required' }, { status: 400 });
  if (!['Weekly', 'Monthly', 'Quarterly'].includes(body.subscription))
    return NextResponse.json({ error: 'valid subscription is required' }, { status: 400 });
  if (typeof body.address !== 'string' || !body.address.trim())
    return NextResponse.json({ error: 'address is required' }, { status: 400 });

  const newCustomer = await addCustomer({
    name: body.name,
    email: body.email,
    subscription: body.subscription as Subscription,
    address: body.address,
  });
  return NextResponse.json({ customer: newCustomer }, { status: 201 });
}

export async function PUT(request: Request) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');
  if (type !== 'orders' && type !== 'customers') {
    return NextResponse.json({ error: 'type query must be orders or customers' }, { status: 400 });
  }
  const body = await request.json();

  if (type === 'orders') {
    if (typeof body.id !== 'string' || !body.id.trim())
      return NextResponse.json({ error: 'id is required' }, { status: 400 });

    const updates: Partial<Omit<Order, 'id'>> = {};

    if (body.customerId !== undefined) {
      if (typeof body.customerId !== 'string' || !body.customerId.trim())
        return NextResponse.json({ error: 'customerId must be a non‑empty string' }, { status: 400 });
      updates.customerId = body.customerId;
    }
    if (body.date !== undefined) {
      if (typeof body.date !== 'string' || !Date.parse(body.date))
        return NextResponse.json({ error: 'date must be a valid ISO string' }, { status: 400 });
      updates.date = body.date;
    }
    if (body.status !== undefined) {
      if (!['Pending', 'Roasting', 'Shipped', 'Cancelled'].includes(body.status))
        return NextResponse.json({ error: 'invalid status' }, { status: 400 });
      updates.status = body.status as OrderStatus;
    }
    if (body.bags !== undefined) {
      if (typeof body.bags !== 'number' || body.bags < 0)
        return NextResponse.json({ error: 'bags must be a non‑negative number' }, { status: 400 });
      updates.bags = body.bags;
    }
    if (body.unitPrice !== undefined) {
      if (typeof body.unitPrice !== 'number' || body.unitPrice < 0)
        return NextResponse.json({ error: 'unitPrice must be a non‑negative number' }, { status: 400 });
      updates.unitPrice = body.unitPrice;
    }

    const updated = await updateOrder(body.id, updates);
    if (!updated) return NextResponse.json({ error: 'order not found' }, { status: 404 });
    return NextResponse.json({ order: updated });
  }

  // customers
  if (typeof body.id !== 'string' || !body.id.trim())
    return NextResponse.json({ error: 'id is required' }, { status: 400 });

  const updates: Partial<Omit<Customer, 'id'>> = {};

  if (body.name !== undefined) {
    if (typeof body.name !== 'string' || !body.name.trim())
      return NextResponse.json({ error: 'name must be a non‑empty string' }, { status: 400 });
    updates.name = body.name;
  }
  if (body.email !== undefined) {
    if (typeof body.email !== 'string' || !body.email.trim())
      return NextResponse.json({ error: 'email must be a non‑empty string' }, { status: 400 });
    updates.email = body.email;
  }
  if (body.subscription !== undefined) {
    if (!['Weekly', 'Monthly', 'Quarterly'].includes(body.subscription))
      return NextResponse.json({ error: 'invalid subscription' }, { status: 400 });
    updates.subscription = body.subscription as Subscription;
  }
  if (body.address !== undefined) {
    if (typeof body.address !== 'string' || !body.address.trim())
      return NextResponse.json({ error: 'address must be a non‑empty string' }, { status: 400 });
    updates.address = body.address;
  }

  const updated = await updateCustomer(body.id, updates);
  if (!updated) return NextResponse.json({ error: 'customer not found' }, { status: 404 });
  return NextResponse.json({ customer: updated });
}