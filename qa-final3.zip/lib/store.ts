import { promises as fs } from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

export type Order = {
  id: string;
  customerId: string;
  date: string;
  status: 'Pending' | 'Roasting' | 'Shipped' | 'Cancelled';
  bags: number;
  unitPrice: number;
};

export type Customer = {
  id: string;
  name: string;
  email: string;
  subscription: 'Weekly' | 'Monthly' | 'Quarterly';
  address: string;
};

const dataDir = process.env.VERCEL ? '/tmp/data' : path.join(process.cwd(), 'data');
const dataFile = path.join(dataDir, 'data.json');

let orders: Order[] = [];
let customers: Customer[] = [];
let initialized = false;

async function ensureInit() {
  if (initialized) return;
  await fs.mkdir(dataDir, { recursive: true });
  try {
    const raw = await fs.readFile(dataFile, 'utf8');
    const parsed = JSON.parse(raw);
    orders = parsed.orders ?? [];
    customers = parsed.customers ?? [];
  } catch {
    customers = [
      {
        id: uuidv4(),
        name: 'Alice Brew',
        email: 'alice@example.com',
        subscription: 'Weekly',
        address: '123 Bean St, Roastville',
      },
      {
        id: uuidv4(),
        name: 'Bob Roast',
        email: 'bob@example.com',
        subscription: 'Monthly',
        address: '456 Aroma Ave, Brewtown',
      },
      {
        id: uuidv4(),
        name: 'Cara Cuppa',
        email: 'cara@example.com',
        subscription: 'Quarterly',
        address: '789 Espresso Rd, Cuppalot',
      },
      {
        id: uuidv4(),
        name: 'Dan Drip',
        email: 'dan@example.com',
        subscription: 'Weekly',
        address: '321 Latte Ln, Drip City',
      },
    ];
    const now = new Date();
    orders = [
      {
        id: uuidv4(),
        customerId: customers[0].id,
        date: new Date(now.getTime() - 2 * 86400000).toISOString(),
        status: 'Pending',
        bags: 2,
        unitPrice: 12.5,
      },
      {
        id: uuidv4(),
        customerId: customers[1].id,
        date: new Date(now.getTime() - 1 * 86400000).toISOString(),
        status: 'Roasting',
        bags: 1,
        unitPrice: 13.0,
      },
      {
        id: uuidv4(),
        customerId: customers[2].id,
        date: now.toISOString(),
        status: 'Shipped',
        bags: 3,
        unitPrice: 11.75,
      },
      {
        id: uuidv4(),
        customerId: customers[3].id,
        date: now.toISOString(),
        status: 'Pending',
        bags: 4,
        unitPrice: 12.0,
      },
      {
        id: uuidv4(),
        customerId: customers[0].id,
        date: now.toISOString(),
        status: 'Cancelled',
        bags: 1,
        unitPrice: 12.5,
      },
      {
        id: uuidv4(),
        customerId: customers[1].id,
        date: now.toISOString(),
        status: 'Pending',
        bags: 2,
        unitPrice: 13.0,
      },
    ];
    await saveData();
  }
  initialized = true;
}

async function saveData() {
  const payload = JSON.stringify({ orders, customers }, null, 2);
  await fs.writeFile(dataFile, payload, 'utf8');
}

export async function getOrders(): Promise<Order[]> {
  await ensureInit();
  return [...orders];
}

export async function getCustomers(): Promise<Customer[]> {
  await ensureInit();
  return [...customers];
}

export async function addOrder(data: Omit<Order, 'id'>): Promise<Order> {
  await ensureInit();
  const newOrder: Order = { id: uuidv4(), ...data };
  orders.push(newOrder);
  await saveData();
  return newOrder;
}

export async function updateOrder(id: string, updates: Partial<Omit<Order, 'id'>>): Promise<Order | null> {
  await ensureInit();
  const idx = orders.findIndex(o => o.id === id);
  if (idx === -1) return null;
  orders[idx] = { ...orders[idx], ...updates };
  await saveData();
  return orders[idx];
}

export async function addCustomer(data: Omit<Customer, 'id'>): Promise<Customer> {
  await ensureInit();
  const newCustomer: Customer = { id: uuidv4(), ...data };
  customers.push(newCustomer);
  await saveData();
  return newCustomer;
}

export async function updateCustomer(id: string, updates: Partial<Omit<Customer, 'id'>>): Promise<Customer | null> {
  await ensureInit();
  const idx = customers.findIndex(c => c.id === id);
  if (idx === -1) return null;
  customers[idx] = { ...customers[idx], ...updates };
  await saveData();
  return customers[idx];
}