import Link from 'next/link';
import './globals.css';

export const metadata = {
  title: 'Ember & Oak — Order Desk',
  description: 'Order desk for Ember & Oak small-batch coffee roastery.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <div className="shell">
          <aside className="sidebar">
            <div className="brand">
              <span className="brand-mark" aria-hidden="true">E&amp;O</span>
              <div className="brand-text">
                <span className="brand-name">Ember &amp; Oak</span>
                <span className="brand-sub">Roastery Order Desk</span>
              </div>
            </div>
            <nav className="nav" aria-label="Main navigation">
              <Link href="/" className="nav-link" aria-current="page">
                Orders
              </Link>
              <Link href="/#customers" className="nav-link">
                Customers
              </Link>
            </nav>
            <div className="sidebar-foot">
              <span className="sidebar-foot-label">Data</span>
              <span className="sidebar-foot-value">Sample records</span>
            </div>
          </aside>
          <main className="main">{children}</main>
        </div>
      </body>
    </html>
  );
}