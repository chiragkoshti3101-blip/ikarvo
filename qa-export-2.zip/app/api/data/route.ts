import { NextRequest, NextResponse } from 'next/server';
import { loadOrders, loadCustomers, saveOrder, saveCustomer, updateOrderStatus, updateCustomerStatus, loadRoastBatches } from '../../../lib/store';
import type { Order, Customer, OrderStatus, CustomerStatus } from '../../../lib/store';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const resource = searchParams.get('resource') || 'orders';
  const q = searchParams.get('q')?.toLowerCase() || '';
  const status = searchParams.get('status') || '';
  const from = searchParams.get('from') || '';
  const to = searchParams.get('to') || '';
  const sortBy = searchParams.get('sortBy') || '';
  const sortDir = searchParams.get('sortDir') || 'asc';

  if (resource === 'customers') {
    let customers = loadCustomers();
    if (q) {
      customers = customers.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q) ||
        c.state.toLowerCase().includes(q) ||
        c.subscriptionPlan.toLowerCase().includes(q) ||
        c.preferredRoast.toLowerCase().includes(q)
      );
    }
    if (status) {
      customers = customers.filter(c => c.status === status);
    }
    if (sortBy) {
      customers = sortCustomers(customers, sortBy, sortDir);
    }
    return NextResponse.json({ customers });
  }

  if (resource === 'roastbatches') {
    const batches = loadRoastBatches();
    return NextResponse.json({ roastBatches: batches });
  }

  let orders = loadOrders();
  if (q) {
    orders = orders.filter(o =>
      o.customerName.toLowerCase().includes(q) ||
      o.subscriptionType.toLowerCase().includes(q) ||
      o.id.toLowerCase().includes(q) ||
      o.roastBatchId?.toLowerCase().includes(q) ||
      o.status.toLowerCase().includes(q)
    );
  }
  if (status) {
    orders = orders.filter(o => o.status === status);
  }
  if (from) {
    orders = orders.filter(o => o.orderDate >= from);
  }
  if (to) {
    orders = orders.filter(o => o.orderDate <= to);
  }
  if (sortBy) {
    orders = sortOrders(orders, sortBy, sortDir);
  }
  return NextResponse.json({ orders });
}

export async function POST(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const resource = searchParams.get('resource') || 'orders';
  const body = await request.json();

  if (resource === 'customers') {
    const validation = validateCustomer(body);
    if (!validation.valid) {
      return NextResponse.json({ error: validation.error }, { status: 400 });
    }
    const customer = saveCustomer(body as Customer);
    return NextResponse.json({ customer }, { status: 201 });
  }

  const validation = validateOrder(body);
  if (!validation.valid) {
    return NextResponse.json({ error: validation.error }, { status: 400 });
  }
  const order = saveOrder(body as Order);
  return NextResponse.json({ order }, { status: 201 });
}

export async function PUT(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const resource = searchParams.get('resource') || 'orders';
  const id = searchParams.get('id');
  if (!id) {
    return NextResponse.json({ error: 'Missing id parameter' }, { status: 400 });
  }

  const body = await request.json();

  if (resource === 'customers') {
    const status = body.status as CustomerStatus;
    const validStatuses: CustomerStatus[] = ['active', 'paused', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return NextResponse.json({ error: 'Invalid customer status' }, { status: 400 });
    }
    const customer = updateCustomerStatus(id, status);
    if (!customer) {
      return NextResponse.json({ error: 'Customer not found' }, { status: 404 });
    }
    return NextResponse.json({ customer });
  }

  const status = body.status as OrderStatus;
  const validStatuses: OrderStatus[] = ['pending', 'confirmed', 'roasting', 'shipped', 'delivered'];
  if (!validStatuses.includes(status)) {
    return NextResponse.json({ error: 'Invalid order status' }, { status: 400 });
  }
  const order = updateOrderStatus(id, status);
  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 });
  }
  return NextResponse.json({ order });
}

function sortOrders(orders: Order[], sortBy: string, sortDir: string): Order[] {
  const dir = sortDir === 'desc' ? -1 : 1;
  return [...orders].sort((a, b) => {
    const aVal = a[sortBy as keyof Order];
    const bVal = b[sortBy as keyof Order];
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return (aVal - bVal) * dir;
    }
    return String(aVal).localeCompare(String(bVal)) * dir;
  });
}

function sortCustomers(customers: Customer[], sortBy: string, sortDir: string): Customer[] {
  const dir = sortDir === 'desc' ? -1 : 1;
  return [...customers].sort((a, b) => {
    const aVal = a[sortBy as keyof Customer];
    const bVal = b[sortBy as keyof Customer];
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return (aVal - bVal) * dir;
    }
    return String(aVal).localeCompare(String(bVal)) * dir;
  });
}

function validateOrder(body: unknown): { valid: boolean; error?: string } {
  const o = body as unknown as Partial<Order>;
  if (!o.customerId || !o.customerName || !o.subscriptionType) {
    return { valid: false, error: 'customerId, customerName, and subscriptionType are required' };
  }
  if (typeof o.bagSize !== 'number' || typeof o.quantity !== 'number' || typeof o.unitPrice !== 'number') {
    return { valid: false, error: 'bagSize, quantity, and unitPrice must be numbers' };
  }
  if (!o.orderDate || !o.deliveryDate) {
    return { valid: false, error: 'orderDate and deliveryDate are required' };
  }
  return { valid: true };
}

function validateCustomer(body: unknown): { valid: boolean; error?: string } {
  const c = body as unknown as Partial<Customer>;
  if (!c.name || !c.email) {
    return { valid: false, error: 'name and email are required' };
  }
  if (!c.subscriptionPlan) {
    return { valid: false, error: 'subscriptionPlan is required' };
  }
  return { valid: true };
}