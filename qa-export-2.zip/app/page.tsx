'use client';
import { useState, useEffect, ChangeEvent } from 'react';
import { Order, Customer, RoastBatch, OrderStatus } from '../lib/store';

type OrderFilter = {
  search: string;
  status: OrderStatus | '';
  startDate: string;
  endDate: string;
};

type CustomerFilter = {
  search: string;
  status: string;
};

export default function DashboardPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [batches, setBatches] = useState<RoastBatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [orderFilter, setOrderFilter] = useState<OrderFilter>({
    search: '',
    status: '',
    startDate: '',
    endDate: '',
  });
  const [customerFilter, setCustomerFilter] = useState<CustomerFilter>({
    search: '',
    status: '',
  });

  useEffect(() => {
    async function loadData() {
      try {
        const [oRes, cRes, bRes] = await Promise.all([
          fetch('/api/data?type=orders'),
          fetch('/api/data?type=customers'),
          fetch('/api/data?type=roastBatches'),
        ]);
        if (!oRes.ok || !cRes.ok || !bRes.ok) throw new Error('Failed to fetch data');
        const [oData, cData, bData] = await Promise.all([oRes.json(), cRes.json(), bRes.json()]);
        setOrders(oData);
        setCustomers(cData);
        setBatches(bData);
        setLoading(false);
      } catch (e: any) {
        setError(e.message);
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleOrderStatusChange = async (orderId: string, newStatus: OrderStatus) => {
    try {
      const res = await fetch('/api/data', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: orderId, status: newStatus, type: 'order' }),
      });
      if (!res.ok) throw new Error('Update failed');
      setOrders(prev => prev.map(o => (o.id === orderId ? { ...o, status: newStatus } : o)));
    } catch (e) {
      alert('Could not update status');
    }
  };

  const filteredOrders = orders.filter(o => {
    const matchesSearch =
      o.customerName.toLowerCase().includes(orderFilter.search.toLowerCase()) ||
      o.subscriptionType.toLowerCase().includes(orderFilter.search.toLowerCase());
    const matchesStatus = orderFilter.status ? o.status === orderFilter.status : true;
    const matchesStart = orderFilter.startDate ? o.orderDate >= orderFilter.startDate : true;
    const matchesEnd = orderFilter.endDate ? o.orderDate <= orderFilter.endDate : true;
    return matchesSearch && matchesStatus && matchesStart && matchesEnd;
  });

  const filteredCustomers = customers.filter(c => {
    const matchesSearch =
      c.name.toLowerCase().includes(customerFilter.search.toLowerCase()) ||
      c.email.toLowerCase().includes(customerFilter.search.toLowerCase());
    const matchesStatus = customerFilter.status ? c.status === customerFilter.status : true;
    return matchesSearch && matchesStatus;
  });

  const totalRevenue = filteredOrders.reduce((sum, o) => sum + o.total, 0);
  const openOrders = filteredOrders.filter(o => o.status !== 'delivered').length;
  const totalBags = filteredOrders.reduce((sum, o) => sum + o.quantity, 0);
  const batchStatusCounts = batches.reduce((acc, b) => {
    acc[b.status] = (acc[b.status] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const exportCSV = () => {
    const header = [
      'Order ID',
      'Customer',
      'Subscription',
      'Bag Size (g)',
      'Quantity',
      'Unit Price',
      'Total',
      'Status',
      'Order Date',
      'Delivery Date',
    ];
    const rows = filteredOrders.map(o => [
      o.id,
      o.customerName,
      o.subscriptionType,
      o.bagSize,
      o.quantity,
      o.unitPrice,
      o.total,
      o.status,
      o.orderDate,
      o.deliveryDate,
    ]);
    const csvContent = [header, ...rows].map(r => r.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'orders.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <div className="loading">Loading…</div>;
  if (error) return <div className="error">Error: {error}</div>;

  return (
    <div className="dashboard">
      <div className="sample-banner">Sample data loaded – changes persist across reloads.</div>
      <div className="kpi-row">
        <div className="kpi-item">
          <div className="kpi-label">Revenue This Week</div>
          <div className="kpi-value">${totalRevenue.toFixed(2)}</div>
        </div>
        <div className="kpi-item">
          <div className="kpi-label">Open Orders</div>
          <div className="kpi-value">{openOrders}</div>
        </div>
        <div className="kpi-item">
          <div className="kpi-label">Bags to Ship</div>
          <div className="kpi-value">{totalBags}</div>
        </div>
        <div className="kpi-item">
          <div className="kpi-label">Batches (Scheduled / Roasting / Packaged)</div>
          <div className="kpi-value">
            {batchStatusCounts['scheduled'] ?? 0} / {batchStatusCounts['roasting'] ?? 0} / {batchStatusCounts['packaged'] ?? 0}
          </div>
        </div>
      </div>

      <section className="orders-section">
        <h2 className="section-title">Weekly Subscription Orders</h2>
        <div className="filters">
          <input
            type="text"
            placeholder="Search customer or subscription"
            value={orderFilter.search}
            onChange={e => setOrderFilter({ ...orderFilter, search: e.target.value })}
            className="filter-input"
          />
          <select
            value={orderFilter.status}
            onChange={e => setOrderFilter({ ...orderFilter, status: e.target.value as OrderStatus })}
            className="filter-select"
          >
            <option value="">All statuses</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="roasting">Roasting</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
          </select>
          <input
            type="date"
            value={orderFilter.startDate}
            onChange={e => setOrderFilter({ ...orderFilter, startDate: e.target.value })}
            className="filter-date"
          />
          <input
            type="date"
            value={orderFilter.endDate}
            onChange={e => setOrderFilter({ ...orderFilter, endDate: e.target.value })}
            className="filter-date"
          />
          <button onClick={exportCSV} className="btn export-btn">
            Export CSV
          </button>
        </div>

        {filteredOrders.length === 0 ? (
          <div className="empty-state">No orders match the current filters.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr className="header-row">
                <th>Order ID</th>
                <th>Customer</th>
                <th>Subscription</th>
                <th>Bag Size (g)</th>
                <th>Qty</th>
                <th>Unit Price</th>
                <th>Total</th>
                <th>Status</th>
                <th>Order Date</th>
                <th>Delivery Date</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.map(o => (
                <tr key={o.id} className="data-row">
                  <td>{o.id}</td>
                  <td>{o.customerName}</td>
                  <td>{o.subscriptionType}</td>
                  <td>{o.bagSize}</td>
                  <td>{o.quantity}</td>
                  <td>${o.unitPrice.toFixed(2)}</td>
                  <td>${o.total.toFixed(2)}</td>
                  <td>
                    <select
                      value={o.status}
                      onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                        handleOrderStatusChange(o.id, e.target.value as OrderStatus)
                      }
                      className="status-select"
                    >
                      <option value="pending">Pending</option>
                      <option value="confirmed">Confirmed</option>
                      <option value="roasting">Roasting</option>
                      <option value="shipped">Shipped</option>
                      <option value="delivered">Delivered</option>
                    </select>
                  </td>
                  <td>{o.orderDate}</td>
                  <td>{o.deliveryDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <section className="customers-section">
        <h2 className="section-title">Customers</h2>
        <div className="filters">
          <input
            type="text"
            placeholder="Search name or email"
            value={customerFilter.search}
            onChange={e => setCustomerFilter({ ...customerFilter, search: e.target.value })}
            className="filter-input"
          />
          <select
            value={customerFilter.status}
            onChange={e => setCustomerFilter({ ...customerFilter, status: e.target.value })}
            className="filter-select"
          >
            <option value="">All statuses</option>
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        {filteredCustomers.length === 0 ? (
          <div className="empty-state">No customers match the current filters.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr className="header-row">
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>City</th>
                <th>Plan</th>
                <th>Status</th>
                <th>Start Date</th>
                <th>Preferred Roast</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map(c => (
                <tr key={c.id} className="data-row">
                  <td>{c.name}</td>
                  <td>{c.email}</td>
                  <td>{c.phone}</td>
                  <td>{c.city}</td>
                  <td>{c.subscriptionPlan}</td>
                  <td>{c.status}</td>
                  <td>{c.startDate}</td>
                  <td>{c.preferredRoast}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}