import fs from 'fs';
import path from 'path';
import { randomUUID } from 'crypto';

export type OrderStatus = 'pending' | 'confirmed' | 'roasting' | 'shipped' | 'delivered';
export type CustomerStatus = 'active' | 'paused' | 'cancelled';
export type BatchStatus = 'scheduled' | 'roasting' | 'cooling' | 'resting' | 'packaged';

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  subscriptionType: string;
  bagSize: number;
  quantity: number;
  unitPrice: number;
  total: number;
  status: OrderStatus;
  orderDate: string;
  deliveryDate: string;
  roastBatchId: string | null;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  subscriptionPlan: string;
  startDate: string;
  status: CustomerStatus;
  preferredRoast: string;
}

export interface RoastBatch {
  id: string;
  batchNumber: string;
  origin: string;
  roastLevel: string;
  quantityKg: number;
  status: BatchStatus;
  scheduledFor: string;
  completedAt: string | null;
}

interface StoreData {
  orders: Order[];
  customers: Customer[];
  roastBatches: RoastBatch[];
}

const DATA_DIR = path.join(process.cwd(), 'data');
const STORE_FILE = path